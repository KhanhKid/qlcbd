-- Status:46:398:MP_0:qlcbd:php:1.24.4::5.5.27:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|đac_điem_lich_su|1|32768||InnoDB
-- TABLE|đanh_gia_can_bo|10|114688||InnoDB
-- TABLE|đao_tao_boi_duong|7|32768||InnoDB
-- TABLE|đon_vi|11|81920||InnoDB
-- TABLE|ban|38|49152||InnoDB
-- TABLE|can_bo|40|49152||InnoDB
-- TABLE|cap_chuc_vu|9|16384||InnoDB
-- TABLE|chieu_huong_phat_trien|3|16384||InnoDB
-- TABLE|chuc_vu|17|32768||InnoDB
-- TABLE|cong_tac_nuoc_ngoai|10|32768||InnoDB
-- TABLE|cong_tac_vien|0|16384||InnoDB
-- TABLE|controller|0|32768||InnoDB
-- TABLE|dan_toc|6|16384||InnoDB
-- TABLE|dien_khen_thuong|0|16384||InnoDB
-- TABLE|hop_đong_cong_tac|0|32768||InnoDB
-- TABLE|khen_thuong|3|65536||InnoDB
-- TABLE|khoi|10|32768||InnoDB
-- TABLE|kien_nghi|28|81920||InnoDB
-- TABLE|kieu_loai_hinh_ban|2|16384||InnoDB
-- TABLE|kq_xet_thi_đua|0|16384||InnoDB
-- TABLE|ky_luat|3|49152||InnoDB
-- TABLE|loai_hinh_ban|9|32768||InnoDB
-- TABLE|ly_lich|39|81920||InnoDB
-- TABLE|module|0|16384||InnoDB
-- TABLE|muc_đo_hoan_thanh|4|16384||InnoDB
-- TABLE|muc_sua_đoi|0|16384||InnoDB
-- TABLE|muc_thuong_theo_dien|0|32768||InnoDB
-- TABLE|ngach_luong|4|16384||InnoDB
-- TABLE|ngoai_ngu|7|16384||InnoDB
-- TABLE|privilege|0|32768||InnoDB
-- TABLE|profile|0|16384||InnoDB
-- TABLE|qua_trinh_cong_tac|6|32768||InnoDB
-- TABLE|qua_trinh_luong|48|65536||InnoDB
-- TABLE|role|3|16384||InnoDB
-- TABLE|role_privilege_relation|0|32768||InnoDB
-- TABLE|status|3|16384||InnoDB
-- TABLE|thanh_vien_gia_đinh|8|65536||InnoDB
-- TABLE|thong_tin_tham_gia_ban|22|180224||InnoDB
-- TABLE|to_cong_tac|0|16384||InnoDB
-- TABLE|ton_giao|8|16384||InnoDB
-- TABLE|trinh_đo_chuyen_mon|9|16384||InnoDB
-- TABLE|trinh_đo_ly_luan_chinh_tri|4|32768||InnoDB
-- TABLE|tt_tai_đon_vi|0|16384||InnoDB
-- TABLE|user|21|81920||InnoDB
-- TABLE|user_log|5|16384||InnoDB
-- TABLE|yeu_cau_thay_đoi_tt_cb|0|49152||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2014-04-01 08:47

--
-- Create Table `đac_điem_lich_su`
--

DROP TABLE IF EXISTS `đac_điem_lich_su`;
CREATE TABLE `đac_điem_lich_su` (
  `Ma_CB` int(11) NOT NULL,
  `Ma_ĐĐLS` bigint(20) NOT NULL,
  `Su_Kien` varchar(254) DEFAULT NULL,
  `Tu_Thoi_Điem` date DEFAULT NULL,
  `Đen_Thoi_Điem` date DEFAULT NULL,
  `Nguoi_Nhan_Khai_Bao` varchar(254) DEFAULT NULL,
  `Noi_Dung` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_ĐĐLS`,`Ma_CB`),
  KEY `FK_cua_Can_Bo_1` (`Ma_CB`),
  CONSTRAINT `FK_cua_Can_Bo_1` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `đac_điem_lich_su`
--

/*!40000 ALTER TABLE `đac_điem_lich_su` DISABLE KEYS */;
INSERT INTO `đac_điem_lich_su` (`Ma_CB`,`Ma_ĐĐLS`,`Su_Kien`,`Tu_Thoi_Điem`,`Đen_Thoi_Điem`,`Nguoi_Nhan_Khai_Bao`,`Noi_Dung`) VALUES ('12','1','học tại ĐH CNTT','2010-09-09','2015-03-03','Dương Anh Đức','nhận bằng tốt nghiệp');
/*!40000 ALTER TABLE `đac_điem_lich_su` ENABLE KEYS */;


--
-- Create Table `đanh_gia_can_bo`
--

DROP TABLE IF EXISTS `đanh_gia_can_bo`;
CREATE TABLE `đanh_gia_can_bo` (
  `Ma_CB_Tu_Đanh_Gia` int(11) NOT NULL,
  `Ngay_Đanh_Gia` date NOT NULL,
  `Noi_Dung_Tu_Đanh_Gia` text,
  `Ma_MĐHT_Tu_Đanh_Gia` tinyint(4) DEFAULT NULL,
  `Ma_ĐV_Muon_Đen` smallint(5) unsigned DEFAULT NULL,
  `Ma_Ban_Muon_Đen` int(11) DEFAULT NULL,
  `Thoi_Gian_Muon_Chuyen` date DEFAULT NULL,
  `Nguyen_Vong_Đao_Tao` text,
  `Ma_CB_Đanh_Gia` int(11) DEFAULT NULL,
  `Noi_Dung_Đanh_Gia` text,
  `Ma_MĐHT` tinyint(4) DEFAULT NULL,
  `Ma_CHPT` tinyint(4) DEFAULT NULL,
  `Đinh_Huong` text,
  PRIMARY KEY (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`),
  KEY `FK_Ban_muon_đen` (`Ma_Ban_Muon_Đen`),
  KEY `FK_Can_Bo_đanh_gia` (`Ma_CB_Đanh_Gia`),
  KEY `FK_chieu_huong_phat_trien_cua_CB` (`Ma_MĐHT`),
  KEY `FK_chieu_huong_phat_trien_cua_CB_tu_đanh_gia` (`Ma_CHPT`),
  KEY `FK_muc_đo_hoan_thanh_cua_CB` (`Ma_MĐHT_Tu_Đanh_Gia`),
  KEY `FK_ĐV_MuonDen` (`Ma_ĐV_Muon_Đen`),
  CONSTRAINT `FK_Ban_muon_đen` FOREIGN KEY (`Ma_Ban_Muon_Đen`) REFERENCES `ban` (`Ma_Ban`),
  CONSTRAINT `FK_Can_Bo_đanh_gia` FOREIGN KEY (`Ma_CB_Đanh_Gia`) REFERENCES `can_bo` (`Ma_Can_Bo`),
  CONSTRAINT `FK_chieu_huong_phat_trien_cua_CB` FOREIGN KEY (`Ma_MĐHT`) REFERENCES `muc_đo_hoan_thanh` (`Ma_MĐHT`),
  CONSTRAINT `FK_chieu_huong_phat_trien_cua_CB_tu_đanh_gia` FOREIGN KEY (`Ma_CHPT`) REFERENCES `chieu_huong_phat_trien` (`Ma_CHPT`),
  CONSTRAINT `FK_co_KQKT` FOREIGN KEY (`Ma_CB_Tu_Đanh_Gia`) REFERENCES `can_bo` (`Ma_Can_Bo`),
  CONSTRAINT `FK_donvi_muonden` FOREIGN KEY (`Ma_ĐV_Muon_Đen`) REFERENCES `đon_vi` (`Ma_ĐV`),
  CONSTRAINT `FK_muc_đo_hoan_thanh_cua_CB` FOREIGN KEY (`Ma_MĐHT_Tu_Đanh_Gia`) REFERENCES `muc_đo_hoan_thanh` (`Ma_MĐHT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `đanh_gia_can_bo`
--

/*!40000 ALTER TABLE `đanh_gia_can_bo` DISABLE KEYS */;
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('0','2014-03-22','a. Ưu điểm:.....\r\n                ',NULL,NULL,NULL,'2014-03-28','+ Chuyên môn nghiệp vụ:......\r\n                ','0','1. Mặt mạnh:.....\r\n                ',NULL,NULL,'+ Quy hoạch:......\r\n                ');
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('0','2014-03-28','a. Ưu điểm:.....\r\n                ',NULL,NULL,NULL,'2014-03-28','+ Chuyên môn nghiệp vụ:......\r\n                ','0','1. Mặt mạnh:.....\r\n                ',NULL,NULL,'+ Quy hoạch:......\r\n                ');
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('2','1970-01-01','a. Ưu điểm:.....\r\n                ','4',NULL,NULL,'1970-01-01','+ Chuyên môn nghiệp vụ:......\r\n                ',NULL,'1. Mặt mạnh:.....\r\n                ','2','3','+ Quy hoạch:......\r\n                ');
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('2','2014-03-14','a. Ưu điểm:.....\r\n                ','3',NULL,NULL,'1970-01-01','+ Chuyên môn nghiệp vụ:......\r\n                ',NULL,'1. Mặt mạnh:.....\r\n                ','3','2','+ Quy hoạch:......\r\n                ');
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('3','2014-03-14','a. Ưu điểm:.....\r\n                ','2',NULL,NULL,'2014-03-14','+ Chuyên môn nghiệp vụ:......\r\n                ',NULL,'1. Mặt mạnh:.....\r\n                ','3','2','+ Quy hoạch:......\r\n                ');
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('4','2014-03-05','','1','1','28','0000-00-00','','1','','1','1','');
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('12','2014-02-11','tốt','1','1','28','2014-03-05','fdsa','1','1','1','1','dfsf');
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('12','2014-03-02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('12','2014-03-12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `đanh_gia_can_bo` (`Ma_CB_Tu_Đanh_Gia`,`Ngay_Đanh_Gia`,`Noi_Dung_Tu_Đanh_Gia`,`Ma_MĐHT_Tu_Đanh_Gia`,`Ma_ĐV_Muon_Đen`,`Ma_Ban_Muon_Đen`,`Thoi_Gian_Muon_Chuyen`,`Nguyen_Vong_Đao_Tao`,`Ma_CB_Đanh_Gia`,`Noi_Dung_Đanh_Gia`,`Ma_MĐHT`,`Ma_CHPT`,`Đinh_Huong`) VALUES ('12','2014-03-14','Ưu điểm: Tốt','1','1','28','2014-03-22','đào tạo cao cấp chính trị','1','tương đối tốt','1','1','cở sở đoàn');
/*!40000 ALTER TABLE `đanh_gia_can_bo` ENABLE KEYS */;


--
-- Create Table `đao_tao_boi_duong`
--

DROP TABLE IF EXISTS `đao_tao_boi_duong`;
CREATE TABLE `đao_tao_boi_duong` (
  `Ma_CB` int(11) NOT NULL,
  `Ma_ĐTBD` bigint(20) NOT NULL AUTO_INCREMENT,
  `Ten_Truong` varchar(254) DEFAULT NULL,
  `Nganh_Hoc` varchar(254) DEFAULT NULL,
  `Thoi_Gian_Hoc` date DEFAULT NULL,
  `TG_Ket_Thuc` date DEFAULT NULL,
  `Hinh_Thuc_Hoc` varchar(254) DEFAULT NULL,
  `Van_Bang_Chung_Chi` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_ĐTBD`,`Ma_CB`),
  KEY `Ma_CB` (`Ma_CB`),
  CONSTRAINT `FK_ĐTBD_cua_Can_Bo` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `đao_tao_boi_duong`
--

/*!40000 ALTER TABLE `đao_tao_boi_duong` DISABLE KEYS */;
INSERT INTO `đao_tao_boi_duong` (`Ma_CB`,`Ma_ĐTBD`,`Ten_Truong`,`Nganh_Hoc`,`Thoi_Gian_Hoc`,`TG_Ket_Thuc`,`Hinh_Thuc_Hoc`,`Van_Bang_Chung_Chi`) VALUES ('1','1','Trường Đoàn Lý Tự Trọng','Trung Cấp Chính Trị','2002-01-16','2002-03-16','Chính quy','Trung Cấp Chính Trị');
INSERT INTO `đao_tao_boi_duong` (`Ma_CB`,`Ma_ĐTBD`,`Ten_Truong`,`Nganh_Hoc`,`Thoi_Gian_Hoc`,`TG_Ket_Thuc`,`Hinh_Thuc_Hoc`,`Van_Bang_Chung_Chi`) VALUES ('12','1','Đại học Chính Trị','Sơ Cấp Chính Trị','2013-03-03','2003-04-03','bổ túc','Sơ Cấp Chính Trị');
INSERT INTO `đao_tao_boi_duong` (`Ma_CB`,`Ma_ĐTBD`,`Ten_Truong`,`Nganh_Hoc`,`Thoi_Gian_Hoc`,`TG_Ket_Thuc`,`Hinh_Thuc_Hoc`,`Van_Bang_Chung_Chi`) VALUES ('1','2','Trường Đoàn Lý Tự Trọng','Cao cấp chính trị','2005-04-04','2005-09-04','chính quy','Cao cấp chính trị');
INSERT INTO `đao_tao_boi_duong` (`Ma_CB`,`Ma_ĐTBD`,`Ten_Truong`,`Nganh_Hoc`,`Thoi_Gian_Hoc`,`TG_Ket_Thuc`,`Hinh_Thuc_Hoc`,`Van_Bang_Chung_Chi`) VALUES ('21','3','NewStar','Mạng máy tính','2014-03-03','2014-03-13','Tập trung','CCNA');
INSERT INTO `đao_tao_boi_duong` (`Ma_CB`,`Ma_ĐTBD`,`Ten_Truong`,`Nganh_Hoc`,`Thoi_Gian_Hoc`,`TG_Ket_Thuc`,`Hinh_Thuc_Hoc`,`Van_Bang_Chung_Chi`) VALUES ('21','4','NewStar','Mạng máy tính','2014-03-17','2014-03-27','Tập trung','CCNA2');
INSERT INTO `đao_tao_boi_duong` (`Ma_CB`,`Ma_ĐTBD`,`Ten_Truong`,`Nganh_Hoc`,`Thoi_Gian_Hoc`,`TG_Ket_Thuc`,`Hinh_Thuc_Hoc`,`Van_Bang_Chung_Chi`) VALUES ('22','5','NewStar','Mạng máy tính','2014-03-03','2014-03-13','Tập trung','CCNA');
INSERT INTO `đao_tao_boi_duong` (`Ma_CB`,`Ma_ĐTBD`,`Ten_Truong`,`Nganh_Hoc`,`Thoi_Gian_Hoc`,`TG_Ket_Thuc`,`Hinh_Thuc_Hoc`,`Van_Bang_Chung_Chi`) VALUES ('22','6','NewStar','Mạng máy tính','2014-03-17','2014-03-27','Tập trung','CCNA2');
/*!40000 ALTER TABLE `đao_tao_boi_duong` ENABLE KEYS */;


--
-- Create Table `đon_vi`
--

DROP TABLE IF EXISTS `đon_vi`;
CREATE TABLE `đon_vi` (
  `Ma_ĐV` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `Ky_Hieu_ĐV` varchar(32) NOT NULL,
  `Ten_Đon_Vi` varchar(254) DEFAULT NULL,
  `Ma_Khoi` tinyint(3) unsigned DEFAULT NULL,
  `Ma_Truong_ĐV` int(11) DEFAULT NULL,
  `Ma_Ban_Chap_Hanh` int(11) DEFAULT NULL,
  `Ngay_Thanh_Lap` date DEFAULT NULL,
  `Chuc_Nang_ĐV` varchar(254) DEFAULT NULL,
  `Đia_Chi` varchar(254) DEFAULT NULL,
  `Email` varchar(126) DEFAULT NULL,
  `So_Đien_Thoai` varchar(62) DEFAULT NULL,
  `Mo_Ta` varchar(254) DEFAULT NULL,
  `Trang_Thai` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`Ma_ĐV`),
  KEY `FK_Co_Ban_Chap_Hanh` (`Ma_Ban_Chap_Hanh`),
  KEY `FK_co_Truong_Đon_Vi` (`Ma_Truong_ĐV`),
  KEY `FK_khoi_truc_thuoc` (`Ma_Khoi`),
  KEY `Ma_Đon_Vi` (`Ky_Hieu_ĐV`),
  CONSTRAINT `FK_Co_Ban_Chap_Hanh` FOREIGN KEY (`Ma_Ban_Chap_Hanh`) REFERENCES `ban` (`Ma_Ban`),
  CONSTRAINT `FK_co_Truong_Đon_Vi` FOREIGN KEY (`Ma_Truong_ĐV`) REFERENCES `can_bo` (`Ma_Can_Bo`),
  CONSTRAINT `FK_khoi_truc_thuoc` FOREIGN KEY (`Ma_Khoi`) REFERENCES `khoi` (`Ma_Khoi`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Data for Table `đon_vi`
--

/*!40000 ALTER TABLE `đon_vi` DISABLE KEYS */;
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('0','','Chuyên Trách Thành Đoàn','4','3','28','2014-03-01',NULL,'','','+8423253543','<p>ĐH Kinh Tế - Luật&nbsp;<br />\r\n&nbsp;</p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('1','BTT1','Báo Tuổi Trẻ','3',NULL,'54','2014-06-03','thông tin liên lạc','12 Nguyễn Thị Minh Khai, Phường 4, Quận 3, TP.HCM','toasoan@baotuoitre.vn','+8423253543','<p>M&ocirc; tả cho đơn vị B&aacute;o Tuổi trẻ</p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('2','CQCTTĐ','Cơ Quan Chuyên Trách Thành Đoàn','2',NULL,NULL,'1999-10-01',NULL,'','','','<p>Cơ Quan Chuy&ecirc;n Tr&aacute;ch Th&agrave;nh Đo&agrave;n quản l&yacute; c&aacute;c vấn đề th&agrave;nh đo&agrave;n TP HCM</p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('3','HDBC','Huyện Đoàn Bình Chánh','4',NULL,'43','1999-01-10',NULL,'','','','<p>- Chức năng nhiệm vụ</p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('4','HDCC','Huyện Đoàn Củ Chi','4',NULL,NULL,'1970-01-01',NULL,'','','','<p>M&ocirc; tả huyện Đo&agrave;n Củ Chi</p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('5','HDCG','Huyện Đoàn Cần Giờ','4',NULL,'46','1994-01-01',NULL,'','','','<p>M&ocirc; tả huyện Đo&agrave;n Cần Giờ</p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('6','UIT','Trường Đại Học Công Nghệ Thông Tin','4','3','29','2006-08-06',NULL,'Linh Chung','admin@uit.edu.vn','(08) 372 52002','<p>M&ocirc; tả cho trường ĐH C&ocirc;ng nghệ Th&ocirc;ng tin - Đại học Quốc Gia TPHCM:</p>\r\n\r\n<p>- Chức năng, nhiệm vụ:</p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('7','UT','Trường ĐH Bách Khoa','4',NULL,'32','2014-01-01',NULL,NULL,NULL,'','<p><strong>M&ocirc; tả cho trường ĐH B&aacute;ch Khoa</strong></p>\r\n','1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('8','UEL','Trường Đại Học Kinh Tế - Luật','2','1','56','2014-03-20',NULL,NULL,NULL,NULL,NULL,'1');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('9','A','Đơn Vị A','4',NULL,NULL,'2014-03-20',NULL,'12 Nguyễn Thị Minh Khai, Phường 4, Quận 3, TP.HCM','toasoan@baotuoitre.vn','+8423253543','<p>kh&ocirc;ng c&oacute;</p>\r\n','0');
INSERT INTO `đon_vi` (`Ma_ĐV`,`Ky_Hieu_ĐV`,`Ten_Đon_Vi`,`Ma_Khoi`,`Ma_Truong_ĐV`,`Ma_Ban_Chap_Hanh`,`Ngay_Thanh_Lap`,`Chuc_Nang_ĐV`,`Đia_Chi`,`Email`,`So_Đien_Thoai`,`Mo_Ta`,`Trang_Thai`) VALUES ('10','B','Đơn Vị B','4',NULL,'61','2001-01-13',NULL,'','donvib@gmail.com','(08) 372 52002','<p>m&ocirc; tả đơn vị</p>\r\n','1');
/*!40000 ALTER TABLE `đon_vi` ENABLE KEYS */;


--
-- Create Table `ban`
--

DROP TABLE IF EXISTS `ban`;
CREATE TABLE `ban` (
  `Ma_Ban` int(11) NOT NULL AUTO_INCREMENT,
  `Ma_Loai_Ban` tinyint(4) DEFAULT NULL,
  `Ma_Đon_Vi` smallint(6) unsigned DEFAULT NULL,
  `Ten_Ban` varchar(254) DEFAULT NULL,
  `Ngay_Thanh_Lap` date DEFAULT NULL,
  `Ngay_Man_Nhiem` date DEFAULT NULL,
  `Mo_Ta` varchar(254) DEFAULT NULL,
  `Trang_Thai` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`Ma_Ban`),
  KEY `FK_loai_cua_ban` (`Ma_Loai_Ban`),
  KEY `FK_thuoc_DV` (`Ma_Đon_Vi`),
  CONSTRAINT `FK_loai_cua_ban` FOREIGN KEY (`Ma_Loai_Ban`) REFERENCES `loai_hinh_ban` (`Ma_Loai_Ban`),
  CONSTRAINT `FK_thuoc_Don_Vi` FOREIGN KEY (`Ma_Đon_Vi`) REFERENCES `đon_vi` (`Ma_ĐV`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

--
-- Data for Table `ban`
--

/*!40000 ALTER TABLE `ban` DISABLE KEYS */;
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('25','1','4','Ban Chấp Hành HĐCC','2013-12-29','1970-01-01','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('26','1','0','Ban Chấp Hành Chuyên Trách Thành Đoàn','2014-01-06','2014-12-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('27','1','6','Ban Chấp Hành trường ĐH Công nghệ Thông tin','2014-01-01','2014-01-07','<p>Mô tả cho BCH trường ĐH Công nghệ Thông tin</p>\r\n','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('28','1','0','Ban Chấp Thánh Chuyên Trách Thành Đoàn 2014 - 2016','2014-01-02','1970-01-01','<p>Mô tả cho BCH trường ĐH Kinh Tế - Luật</p>\r\n','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('29','1','6','Ban Chấp Hành trường ĐH Công nghệ Thông tin','2014-01-07',NULL,'<p>12345</p>\r\n','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('30','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('31','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('32','1','7','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('33','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('34','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('35','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('36','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('37','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('38','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('39','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('40','1','7','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('41','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('42','1','0','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2013-12-25','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('43','1','7','Ban Chấp Hành Trường ĐH Bách Khoa - nhiệm kỳ 2013','2013-12-25','2014-03-12','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('44','1','0','Ban Chấp Hành Báo Tuổi Trẻ - nhiệm kỳ 2014','2014-10-03','2014-10-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('45','1','0','Ban Chấp Hành Báo Tuổi Trẻ - nhiệm kỳ 2014','2014-10-03','2014-10-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('46','1','1','Ban Chấp Hành Báo Tuổi Trẻ - nhiệm kỳ 2014','2014-10-03',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('47','1','0','','2014-12-03','2014-12-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('48','1','0','','2014-12-03','2014-12-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('49','1','0','','2014-12-03','2014-12-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('50','1','0','','2014-12-03','2014-12-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('51','1','0','','2014-12-03','2014-12-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('52','1','0','Ban Chấp Hành Báo Tuổi Trẻ - nhiệm kỳ 2014','2014-12-03','2014-10-03','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('53','1','1','Ban Chấp Hành Báo Tuổi Trẻ - nhiệm kỳ 2014','2014-10-03','1970-01-01','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('54','1','1','Ban Chấp Hành Báo Tuổi Trẻ - nhiệm kỳ NaN','1970-01-01','2014-01-01','','0');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('55','1','3','Ban Chấp Hành  - nhiệm kỳ 2016','2016-03-10',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('56','1','8','Ban Chấp Hành trường ĐH Kinh Tế - Luật','2014-03-20',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('57','1','9','Ban Chấp Hành Đơn Vị A - 2014','1970-01-01',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('58','1','10','Ban Chấp Hành Đơn Vị B 2014','1970-01-01',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('59','1','10','Ban Chấp Hành Đơn Vị B','1970-01-01',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('60','1','9','Ban Chấp Hành Đơn Vị A','1970-01-01',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('61','1','10','Ban Chấp Hành Đơn Vị B','1970-01-01',NULL,'','1');
INSERT INTO `ban` (`Ma_Ban`,`Ma_Loai_Ban`,`Ma_Đon_Vi`,`Ten_Ban`,`Ngay_Thanh_Lap`,`Ngay_Man_Nhiem`,`Mo_Ta`,`Trang_Thai`) VALUES ('62',NULL,NULL,NULL,'2014-03-31',NULL,'<p>M&ocirc; tả cho ph&ograve;ng kế to&aacute;n</p>\r\n','1');
/*!40000 ALTER TABLE `ban` ENABLE KEYS */;


--
-- Create Table `can_bo`
--

DROP TABLE IF EXISTS `can_bo`;
CREATE TABLE `can_bo` (
  `Ma_Can_Bo` int(11) NOT NULL AUTO_INCREMENT,
  `Ma_Quan_Ly` varchar(254) DEFAULT NULL COMMENT 'MaDoiTuong, MaKhuVuc, STT',
  `Ma_CV_Chinh` smallint(5) unsigned DEFAULT NULL COMMENT 'tham chiếu chức vụ chính của cán bộ',
  `Ho_Ten_CB` varchar(254) DEFAULT '(chưa biết)',
  `Ngay_Gia_Nhap` date DEFAULT NULL,
  `Ngay_Tuyen_Dung` date DEFAULT NULL,
  `Ngay_Bien_Che` date DEFAULT NULL,
  `Ma_ĐVCT_Chinh` smallint(5) unsigned DEFAULT NULL,
  `Ngay_Roi_Khoi` date DEFAULT NULL,
  `Trang_Thai` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 - Đang công tác, 0 - Đã rời khỏi, (-1) - đã mất',
  `Tham_Gia_CLBTT` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Ma_Can_Bo`),
  KEY `FK_co_Chuc_Vu_Chinh` (`Ma_CV_Chinh`),
  KEY `FK_co_ĐVCT_Chinh` (`Ma_ĐVCT_Chinh`),
  CONSTRAINT `FK_co_Chuc_Vu_Chinh` FOREIGN KEY (`Ma_CV_Chinh`) REFERENCES `chuc_vu` (`Ma_Chuc_Vu`),
  CONSTRAINT `FK_thuoc_DonViChinh` FOREIGN KEY (`Ma_ĐVCT_Chinh`) REFERENCES `đon_vi` (`Ma_ĐV`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

--
-- Data for Table `can_bo`
--

/*!40000 ALTER TABLE `can_bo` DISABLE KEYS */;
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('0',NULL,NULL,'Anonymous',NULL,NULL,NULL,NULL,'0001-01-01','0','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('1',NULL,'1','Nguyễn Trác Thức','2006-10-10',NULL,NULL,'0',NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('2',NULL,'3','Lê Đức Thịnh','2007-07-06',NULL,NULL,'0',NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('3',NULL,'5','Hoàng Anh Hùng','2009-03-04',NULL,NULL,'0',NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('4',NULL,'5','Trần Đình Thi','2011-02-03',NULL,NULL,'0',NULL,'1','1');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('12','01-56-11','1','Nguyễn Tuấn Anh','2014-01-08','2014-01-01','2014-01-13','0',NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('13',NULL,NULL,'Trần Phương Anh','2009-11-23','2009-11-23','2009-11-23',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('14',NULL,NULL,'Trần Phương Anh','2009-11-23','2009-11-23','2009-11-23',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('15',NULL,NULL,'Trần Phương Anh','2009-11-23','2009-11-23','2009-11-23',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('16',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('17',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('18',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('19',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('20',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('21',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('22',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('23',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('24',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('25',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('26',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('27',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('28',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('29',NULL,NULL,'Châu Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('30',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('31',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('32',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('33',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('34',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('35',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('36',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('37',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('38',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('39',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('40',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('41',NULL,NULL,'Hoàng Ngọc Hòa','2014-03-26','2014-03-26','2014-03-26',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('42',NULL,NULL,'Trương Đăng Khoa','2014-03-27','2014-03-27','2014-03-27',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('44',NULL,NULL,'Lưu Trọng Đạt','2014-03-29','2014-03-29','2014-03-29',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('45',NULL,NULL,'','2014-03-28','2014-03-28','2014-03-28',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('46',NULL,NULL,'A1','2014-03-28','2014-03-28','2014-03-28',NULL,NULL,'1','0');
INSERT INTO `can_bo` (`Ma_Can_Bo`,`Ma_Quan_Ly`,`Ma_CV_Chinh`,`Ho_Ten_CB`,`Ngay_Gia_Nhap`,`Ngay_Tuyen_Dung`,`Ngay_Bien_Che`,`Ma_ĐVCT_Chinh`,`Ngay_Roi_Khoi`,`Trang_Thai`,`Tham_Gia_CLBTT`) VALUES ('47',NULL,NULL,'A2','2014-03-28','2014-03-28','2014-03-28',NULL,NULL,'1','0');
/*!40000 ALTER TABLE `can_bo` ENABLE KEYS */;


--
-- Create Table `cap_chuc_vu`
--

DROP TABLE IF EXISTS `cap_chuc_vu`;
CREATE TABLE `cap_chuc_vu` (
  `Ma_Cap` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Ten_Cap_CV` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_Cap`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Data for Table `cap_chuc_vu`
--

/*!40000 ALTER TABLE `cap_chuc_vu` DISABLE KEYS */;
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('0','Khác');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('1','Trưởng Đơn Vị');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('2','Phó Đơn Vị');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('3','Thường Trực');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('4','Thường Vụ/ Thành Viên Hội Đồng');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('5','Ủy Viên');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('6','Trưởng Phòng/Ban');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('7','Phó Phòng/Ban');
INSERT INTO `cap_chuc_vu` (`Ma_Cap`,`Ten_Cap_CV`) VALUES ('8','Cán Bộ/Nhân Viên');
/*!40000 ALTER TABLE `cap_chuc_vu` ENABLE KEYS */;


--
-- Create Table `chieu_huong_phat_trien`
--

DROP TABLE IF EXISTS `chieu_huong_phat_trien`;
CREATE TABLE `chieu_huong_phat_trien` (
  `Ma_CHPT` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Ten_CHPT` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_CHPT`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `chieu_huong_phat_trien`
--

/*!40000 ALTER TABLE `chieu_huong_phat_trien` DISABLE KEYS */;
INSERT INTO `chieu_huong_phat_trien` (`Ma_CHPT`,`Ten_CHPT`) VALUES ('1','Tốt hơn');
INSERT INTO `chieu_huong_phat_trien` (`Ma_CHPT`,`Ten_CHPT`) VALUES ('2','Giứ mức');
INSERT INTO `chieu_huong_phat_trien` (`Ma_CHPT`,`Ten_CHPT`) VALUES ('3','Giảm');
/*!40000 ALTER TABLE `chieu_huong_phat_trien` ENABLE KEYS */;


--
-- Create Table `chuc_vu`
--

DROP TABLE IF EXISTS `chuc_vu`;
CREATE TABLE `chuc_vu` (
  `Ma_Chuc_Vu` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Ma_Cap` tinyint(4) DEFAULT NULL,
  `Ten_Chuc_Vu` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_Chuc_Vu`),
  KEY `FK_cap_đo_cua_CV` (`Ma_Cap`),
  CONSTRAINT `FK_cap_đo_cua_CV` FOREIGN KEY (`Ma_Cap`) REFERENCES `cap_chuc_vu` (`Ma_Cap`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Data for Table `chuc_vu`
--

/*!40000 ALTER TABLE `chuc_vu` DISABLE KEYS */;
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('0',NULL,'Khác');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('1','1','Bí Thư');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('2','1','Giám Đốc');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('3','2','Phó Bí Thư');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('4','2','Phó Giám Đốc');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('5','3','Thường Trực');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('6','4','Thường Vụ');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('7','4','Thành Viên Hội Đồng');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('8','5','Ủy Viên BCH');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('9','6','Trưởng Ban');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('10','6','Kế Toán Trưởng');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('11','6','Trưởng Phòng');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('12','7','Phó Ban');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('13','7','Kế Toán Phó');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('14','7','Phó Phòng');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('15','8','Cán Bộ');
INSERT INTO `chuc_vu` (`Ma_Chuc_Vu`,`Ma_Cap`,`Ten_Chuc_Vu`) VALUES ('16','8','Nhân Viên');
/*!40000 ALTER TABLE `chuc_vu` ENABLE KEYS */;


--
-- Create Table `cong_tac_nuoc_ngoai`
--

DROP TABLE IF EXISTS `cong_tac_nuoc_ngoai`;
CREATE TABLE `cong_tac_nuoc_ngoai` (
  `Ma_CB` int(10) unsigned NOT NULL,
  `Ma_CTNN` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Tu_Ngay` date NOT NULL DEFAULT '0000-00-00',
  `Đen_Ngay` date NOT NULL DEFAULT '0000-00-00',
  `Đia_Điem` varchar(254) DEFAULT NULL,
  `Noi_Dung` varchar(254) DEFAULT NULL,
  `Cap_Cu_Đi` varchar(254) DEFAULT NULL,
  `Kinh_Phi` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_CTNN`,`Ma_CB`),
  KEY `Ma_CTNN` (`Ma_CTNN`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

--
-- Data for Table `cong_tac_nuoc_ngoai`
--

/*!40000 ALTER TABLE `cong_tac_nuoc_ngoai` DISABLE KEYS */;
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('1','1','2014-02-04','2014-03-04','Hoa Kỳ','giao lưu giảng viên đại học','cấp quốc gia','- đài thọ: 50.000.000 VNĐ');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('1','2','2014-03-13','2014-03-17','Nga','hội nghị nghiên cứu khoa học','cấp thành','- đài thọ 30.000.000 VNĐ\r\n- tự túc ăn uống');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('3','3','2014-03-25','2014-03-28','Úc','Tham quan','Thành Phố',' đài thọ hoàn toàn');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('4','4','2014-03-01','2014-03-08','Nhật Bản','giao lưu văn hóa sinh viên Việt - Nhật','cấp thành phố','đài thọ hoàn toàn (khoảng 10 triệu VNĐ), 10 triệu cho phí phát sinh');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('12','5','2013-08-04','2013-09-25','Singapo','ngắm cảnh','cấp nhà','4.000.000 VNĐ');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('12','6','2013-10-01','2014-03-20','Hàn Quốc','giao lưu các trường đại học châu Á','cấp trường','đài thọ hoàn toàn (cao nhất 20 triệu)');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('12','7','2014-02-05','2014-02-13','Hồng Công','đi chơi','cấp nhà','tự túc 2.000.000 VNĐ');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('1','8','2014-03-28','2014-03-28','Singapo','Tham quan','Thành Phố',' tự túc');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('4','9','2014-03-28','2014-03-28','Nga','Tham quan','Thành Phố',' ');
INSERT INTO `cong_tac_nuoc_ngoai` (`Ma_CB`,`Ma_CTNN`,`Tu_Ngay`,`Đen_Ngay`,`Đia_Điem`,`Noi_Dung`,`Cap_Cu_Đi`,`Kinh_Phi`) VALUES ('3','10','2014-03-29','2014-03-30','Nga','hội nghị nghiên cứu khoa học','Thành Phố','tự túc');
/*!40000 ALTER TABLE `cong_tac_nuoc_ngoai` ENABLE KEYS */;


--
-- Create Table `cong_tac_vien`
--

DROP TABLE IF EXISTS `cong_tac_vien`;
CREATE TABLE `cong_tac_vien` (
  `Ma_CTV` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Ho_Ten_CTV` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_CTV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `cong_tac_vien`
--

/*!40000 ALTER TABLE `cong_tac_vien` DISABLE KEYS */;
/*!40000 ALTER TABLE `cong_tac_vien` ENABLE KEYS */;


--
-- Create Table `controller`
--

DROP TABLE IF EXISTS `controller`;
CREATE TABLE `controller` (
  `Controller_Name` varchar(32) NOT NULL,
  `Module_Name` varchar(32) DEFAULT NULL,
  `Controller_Display_Name` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Controller_Name`),
  KEY `FK_of_module` (`Module_Name`),
  CONSTRAINT `FK_of_module` FOREIGN KEY (`Module_Name`) REFERENCES `module` (`Module_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `controller`
--

/*!40000 ALTER TABLE `controller` DISABLE KEYS */;
/*!40000 ALTER TABLE `controller` ENABLE KEYS */;


--
-- Create Table `dan_toc`
--

DROP TABLE IF EXISTS `dan_toc`;
CREATE TABLE `dan_toc` (
  `Ma_Dan_Toc` smallint(6) NOT NULL AUTO_INCREMENT,
  `Ten_Dan_Toc` varchar(63) DEFAULT NULL,
  PRIMARY KEY (`Ma_Dan_Toc`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Data for Table `dan_toc`
--

/*!40000 ALTER TABLE `dan_toc` DISABLE KEYS */;
INSERT INTO `dan_toc` (`Ma_Dan_Toc`,`Ten_Dan_Toc`) VALUES ('1','Kinh');
INSERT INTO `dan_toc` (`Ma_Dan_Toc`,`Ten_Dan_Toc`) VALUES ('2','Chăm');
INSERT INTO `dan_toc` (`Ma_Dan_Toc`,`Ten_Dan_Toc`) VALUES ('3','Hoa');
INSERT INTO `dan_toc` (`Ma_Dan_Toc`,`Ten_Dan_Toc`) VALUES ('4','Thái');
INSERT INTO `dan_toc` (`Ma_Dan_Toc`,`Ten_Dan_Toc`) VALUES ('5','Tày');
INSERT INTO `dan_toc` (`Ma_Dan_Toc`,`Ten_Dan_Toc`) VALUES ('6','Nùng');
/*!40000 ALTER TABLE `dan_toc` ENABLE KEYS */;


--
-- Create Table `dien_khen_thuong`
--

DROP TABLE IF EXISTS `dien_khen_thuong`;
CREATE TABLE `dien_khen_thuong` (
  `Ma_Dien` smallint(6) NOT NULL AUTO_INCREMENT,
  `Ten_Dien` varchar(254) DEFAULT NULL,
  `Muc_Thuong_Khung` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Ma_Dien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `dien_khen_thuong`
--

/*!40000 ALTER TABLE `dien_khen_thuong` DISABLE KEYS */;
/*!40000 ALTER TABLE `dien_khen_thuong` ENABLE KEYS */;


--
-- Create Table `hop_đong_cong_tac`
--

DROP TABLE IF EXISTS `hop_đong_cong_tac`;
CREATE TABLE `hop_đong_cong_tac` (
  `Ma_Ban` int(11) NOT NULL,
  `Ma_CTV` int(10) unsigned NOT NULL,
  `Ngay_Bat_Đau` datetime NOT NULL,
  `Ngay_Ket_Thuc` date DEFAULT NULL,
  `Nhiem_Vu` varchar(254) DEFAULT NULL,
  `Tien_Luong_Khoan` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Ma_Ban`,`Ma_CTV`,`Ngay_Bat_Đau`),
  KEY `FK_CTV_Hop_Đong` (`Ma_CTV`),
  CONSTRAINT `FK_Ban_Hop_Đong` FOREIGN KEY (`Ma_Ban`) REFERENCES `ban` (`Ma_Ban`),
  CONSTRAINT `FK_CTV_Hop_Đong` FOREIGN KEY (`Ma_CTV`) REFERENCES `cong_tac_vien` (`Ma_CTV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `hop_đong_cong_tac`
--

/*!40000 ALTER TABLE `hop_đong_cong_tac` DISABLE KEYS */;
/*!40000 ALTER TABLE `hop_đong_cong_tac` ENABLE KEYS */;


--
-- Create Table `khen_thuong`
--

DROP TABLE IF EXISTS `khen_thuong`;
CREATE TABLE `khen_thuong` (
  `Ma_CB` int(11) NOT NULL,
  `Ma_Khen_Thuong` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Ngay_Quyet_Đinh` date DEFAULT NULL,
  `Hinh_Thuc` varchar(62) DEFAULT NULL,
  `Cap_Ra_Quyet_Đinh` varchar(62) DEFAULT NULL,
  `Ly_Do` varchar(254) DEFAULT NULL,
  `Ma_DS_Khen_Thuong` int(10) unsigned DEFAULT NULL,
  `Ma_Dien` smallint(6) DEFAULT NULL,
  `He_So_Thuong` float DEFAULT '1',
  PRIMARY KEY (`Ma_Khen_Thuong`,`Ma_CB`),
  KEY `FK_thuoc_dien` (`Ma_Dien`),
  KEY `FK_thuoc_kq_xet` (`Ma_DS_Khen_Thuong`),
  KEY `Ma_CB` (`Ma_CB`),
  CONSTRAINT `FK_khen_thuong_can_bo` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`),
  CONSTRAINT `FK_thuoc_dien` FOREIGN KEY (`Ma_Dien`) REFERENCES `dien_khen_thuong` (`Ma_Dien`),
  CONSTRAINT `khen_thuong_ibfk_1` FOREIGN KEY (`Ma_DS_Khen_Thuong`) REFERENCES `kq_xet_thi_đua` (`Ma_DS_Khen_Thuong`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `khen_thuong`
--

/*!40000 ALTER TABLE `khen_thuong` DISABLE KEYS */;
INSERT INTO `khen_thuong` (`Ma_CB`,`Ma_Khen_Thuong`,`Ngay_Quyet_Đinh`,`Hinh_Thuc`,`Cap_Ra_Quyet_Đinh`,`Ly_Do`,`Ma_DS_Khen_Thuong`,`Ma_Dien`,`He_So_Thuong`) VALUES ('28','1','2014-03-12','Giấy khen','Thành Đoàn','Hoàn thành nhiệm vụ',NULL,NULL,'1');
INSERT INTO `khen_thuong` (`Ma_CB`,`Ma_Khen_Thuong`,`Ngay_Quyet_Đinh`,`Hinh_Thuc`,`Cap_Ra_Quyet_Đinh`,`Ly_Do`,`Ma_DS_Khen_Thuong`,`Ma_Dien`,`He_So_Thuong`) VALUES ('29','2','2014-03-12','Giấy khen','Thành Đoàn','Hoàn thành nhiệm vụ',NULL,NULL,'1');
INSERT INTO `khen_thuong` (`Ma_CB`,`Ma_Khen_Thuong`,`Ngay_Quyet_Đinh`,`Hinh_Thuc`,`Cap_Ra_Quyet_Đinh`,`Ly_Do`,`Ma_DS_Khen_Thuong`,`Ma_Dien`,`He_So_Thuong`) VALUES ('29','3','2014-03-27','Giấy khen','Thành Đoàn','Hoàn thành nhiệm vụ',NULL,NULL,'1');
/*!40000 ALTER TABLE `khen_thuong` ENABLE KEYS */;


--
-- Create Table `khoi`
--

DROP TABLE IF EXISTS `khoi`;
CREATE TABLE `khoi` (
  `Ma_Khoi` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `Ten_Khoi` varchar(254) DEFAULT NULL,
  `Mo_Ta` varchar(254) DEFAULT NULL,
  `Ma_Khoi_Cap_Tren` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`Ma_Khoi`),
  KEY `FK_khoi_cap_tren_truc_thuoc` (`Ma_Khoi_Cap_Tren`),
  CONSTRAINT `FK_khoi_cap_tren_truc_thuoc` FOREIGN KEY (`Ma_Khoi_Cap_Tren`) REFERENCES `khoi` (`Ma_Khoi`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Data for Table `khoi`
--

/*!40000 ALTER TABLE `khoi` DISABLE KEYS */;
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('1','Thành Đoàn',NULL,NULL);
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('2','Khối cơ quan chuyên trách Thành Đoàn',NULL,'1');
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('3','Khối các đơn vị sự nghiệp - doanh nghiệp',NULL,'1');
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('4','Cơ Sở Đoàn',NULL,'1');
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('5','Cơ Quan Chính Đảng',NULL,NULL);
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('6','VD',NULL,NULL);
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('7','VD',NULL,NULL);
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('8','VD2',NULL,NULL);
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('9','VD2',NULL,NULL);
INSERT INTO `khoi` (`Ma_Khoi`,`Ten_Khoi`,`Mo_Ta`,`Ma_Khoi_Cap_Tren`) VALUES ('10','VD2',NULL,NULL);
/*!40000 ALTER TABLE `khoi` ENABLE KEYS */;


--
-- Create Table `kien_nghi`
--

DROP TABLE IF EXISTS `kien_nghi`;
CREATE TABLE `kien_nghi` (
  `Thoi_Gian` datetime NOT NULL,
  `Ma_CB_Kien_Nghi` int(11) NOT NULL,
  `Ten_Kien_Nghi` varchar(254) DEFAULT NULL,
  `Noi_Dung` text,
  `File_URL` varchar(254) DEFAULT NULL,
  `Trang_Thai` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`Thoi_Gian`,`Ma_CB_Kien_Nghi`),
  KEY `FK_đuoc_can_bo_yeu_cau` (`Ma_CB_Kien_Nghi`),
  KEY `Trang_Thai` (`Trang_Thai`),
  KEY `Thoi_Gian` (`Thoi_Gian`),
  KEY `FK_co_CB_kiennghi` (`Ma_CB_Kien_Nghi`),
  CONSTRAINT `FK_co_CB_kiennghi` FOREIGN KEY (`Ma_CB_Kien_Nghi`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `kien_nghi`
--

/*!40000 ALTER TABLE `kien_nghi` DISABLE KEYS */;
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-25 23:44:27','12','Đổi CMND','chứng mình nhân dân bị sai',NULL,'0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-26 00:22:55','3','Tên họ Sai','đổi lại tên',NULL,'0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-26 00:50:43','4','Nâng lương trước thời hạn','Yêu cầu được nâng lương trước thời hạn',NULL,'-1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-26 13:59:20','3','Đổi CMND','Số CMND đúng 3542334354       ',NULL,'0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 04:54:47','4','a','a',NULL,'-1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 04:55:20','4','a','a',NULL,'0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 04:57:58','4','v','vc',NULL,'-1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 04:58:04','4','v','v',NULL,'0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 04:59:10','4','q','a',NULL,'-1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 04:59:33','4','a','a',NULL,'-1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 05:05:07','4','b','b',NULL,'0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 05:11:34','4','d','g',NULL,'0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 05:11:57','4','b','g',NULL,'-1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 05:14:03','4','d','fd',NULL,'-1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 06:28:37','3','v','f','3_1396135717.zip','0');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 06:31:33','3','fdf','àd','3_1396135893.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 06:31:34','3','fdf','àd','3_1396135894.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 06:31:35','3','fdf','àd','3_1396135895.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 06:31:36','3','fdf','àd','3_1396135896.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 06:31:37','3','fdf','àd','3_1396135897.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 15:03:10','3','A','V','3_1396166590.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 15:03:28','3','A','V','3_1396166608.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 15:08:49','3','f','v','3_1396166929.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 15:11:55','3','a','fd',NULL,'1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 15:13:53','3','a','fd',NULL,'1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 15:20:50','3','f','a',NULL,'1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 18:13:02','3','a','d','3_1396177982.zip','1');
INSERT INTO `kien_nghi` (`Thoi_Gian`,`Ma_CB_Kien_Nghi`,`Ten_Kien_Nghi`,`Noi_Dung`,`File_URL`,`Trang_Thai`) VALUES ('2014-03-30 18:13:48','3','a','d','3_1396178028.zip','-1');
/*!40000 ALTER TABLE `kien_nghi` ENABLE KEYS */;


--
-- Create Table `kieu_loai_hinh_ban`
--

DROP TABLE IF EXISTS `kieu_loai_hinh_ban`;
CREATE TABLE `kieu_loai_hinh_ban` (
  `Ma_KLHB` tinyint(4) NOT NULL,
  `Ten_KLHB` varchar(62) DEFAULT NULL,
  `Mo_Ta` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_KLHB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `kieu_loai_hinh_ban`
--

/*!40000 ALTER TABLE `kieu_loai_hinh_ban` DISABLE KEYS */;
INSERT INTO `kieu_loai_hinh_ban` (`Ma_KLHB`,`Ten_KLHB`,`Mo_Ta`) VALUES ('0','Phòng/Ban chức năng',NULL);
INSERT INTO `kieu_loai_hinh_ban` (`Ma_KLHB`,`Ten_KLHB`,`Mo_Ta`) VALUES ('1','Ban Lãnh Đạo',NULL);
/*!40000 ALTER TABLE `kieu_loai_hinh_ban` ENABLE KEYS */;


--
-- Create Table `kq_xet_thi_đua`
--

DROP TABLE IF EXISTS `kq_xet_thi_đua`;
CREATE TABLE `kq_xet_thi_đua` (
  `Ma_DS_Khen_Thuong` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Nam_Đanh_Gia` smallint(6) NOT NULL,
  `Quy_Đanh_Gia` smallint(6) NOT NULL,
  `Thoi_Điem_Xet` date DEFAULT NULL,
  PRIMARY KEY (`Ma_DS_Khen_Thuong`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `kq_xet_thi_đua`
--

/*!40000 ALTER TABLE `kq_xet_thi_đua` DISABLE KEYS */;
/*!40000 ALTER TABLE `kq_xet_thi_đua` ENABLE KEYS */;


--
-- Create Table `ky_luat`
--

DROP TABLE IF EXISTS `ky_luat`;
CREATE TABLE `ky_luat` (
  `Ma_CB` int(11) NOT NULL,
  `Ma_Ky_Luat` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Ngay_Quyet_Đinh` date DEFAULT NULL,
  `Hinh_Thuc` varchar(62) DEFAULT NULL,
  `Cap_Ra_Quyet_Đinh` varchar(62) DEFAULT NULL,
  `Ly_Do_Ky_Luat` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_Ky_Luat`,`Ma_CB`),
  KEY `FK_ky_luat_cua_can_bo` (`Ma_CB`),
  KEY `Ma_CB` (`Ma_CB`),
  CONSTRAINT `FK_ky_luat_cua_can_bo` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `ky_luat`
--

/*!40000 ALTER TABLE `ky_luat` DISABLE KEYS */;
INSERT INTO `ky_luat` (`Ma_CB`,`Ma_Ky_Luat`,`Ngay_Quyet_Đinh`,`Hinh_Thuc`,`Cap_Ra_Quyet_Đinh`,`Ly_Do_Ky_Luat`) VALUES ('12','1','2014-03-25','Khiển trách','cấp trường','lơ là công việc');
INSERT INTO `ky_luat` (`Ma_CB`,`Ma_Ky_Luat`,`Ngay_Quyet_Đinh`,`Hinh_Thuc`,`Cap_Ra_Quyet_Đinh`,`Ly_Do_Ky_Luat`) VALUES ('24','2','2014-03-04','Khiển trách','Thành Đoàn','Không hoàn thành nhiệm vụ');
INSERT INTO `ky_luat` (`Ma_CB`,`Ma_Ky_Luat`,`Ngay_Quyet_Đinh`,`Hinh_Thuc`,`Cap_Ra_Quyet_Đinh`,`Ly_Do_Ky_Luat`) VALUES ('24','3','2014-03-20','Cảnh cáo','Thành Đoàn','Không hoàn thành nhiệm vụ');
/*!40000 ALTER TABLE `ky_luat` ENABLE KEYS */;


--
-- Create Table `loai_hinh_ban`
--

DROP TABLE IF EXISTS `loai_hinh_ban`;
CREATE TABLE `loai_hinh_ban` (
  `Ma_Loai_Ban` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Ten_Loai_Hinh_Ban` varchar(62) DEFAULT NULL,
  `Mo_Ta` varchar(254) DEFAULT NULL,
  `Ma_Kieu_Loai_Hinh` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`Ma_Loai_Ban`),
  KEY `FK_co_KieuLHB` (`Ma_Kieu_Loai_Hinh`),
  CONSTRAINT `FK_co_KieuLHB` FOREIGN KEY (`Ma_Kieu_Loai_Hinh`) REFERENCES `kieu_loai_hinh_ban` (`Ma_KLHB`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Data for Table `loai_hinh_ban`
--

/*!40000 ALTER TABLE `loai_hinh_ban` DISABLE KEYS */;
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('1','Ban Chấp Hành','Ban chấp hình các cơ quan. Chú ý: Ban Thường Vụ là các Cán bộ giữ chức Thường Vụ tại Ban Chấp Hành cơ quan đó ','1');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('2','Hội Đồng Thành Viên','Hội đồng thành viên, giành cho các cơ quan doanh nghiệp','1');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('3','Phòng Kế Toán',NULL,'0');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('4','Phòng Hành Chính',NULL,'0');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('5','Ban Biên Tập',NULL,'0');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('6','Ban Giám Hiệu','đối với các cơ quan Trường học','1');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('7','Ban Giám Đốc',NULL,'1');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('8','Phòng Kinh Doanh',NULL,'0');
INSERT INTO `loai_hinh_ban` (`Ma_Loai_Ban`,`Ten_Loai_Hinh_Ban`,`Mo_Ta`,`Ma_Kieu_Loai_Hinh`) VALUES ('9','Ban Phát Thanh Truyền Hình','','0');
/*!40000 ALTER TABLE `loai_hinh_ban` ENABLE KEYS */;


--
-- Create Table `ly_lich`
--

DROP TABLE IF EXISTS `ly_lich`;
CREATE TABLE `ly_lich` (
  `Ma_CB` int(11) NOT NULL,
  `So_Hieu_CB` varchar(30) DEFAULT NULL COMMENT 'dùng để quản lý hồ sơ lý lịch (MaDoiTuong, MaKhuVuc, STT)',
  `Ho_Ten_Khai_Sinh` varchar(254) DEFAULT NULL,
  `Ten_Goi_Khac` varchar(254) DEFAULT NULL,
  `Gioi_Tinh` tinyint(1) DEFAULT NULL,
  `Cap_Uy_Hien_Tai` varchar(254) DEFAULT NULL,
  `Cap_Uy_Kiem` varchar(254) DEFAULT NULL,
  `Chuc_Danh` varchar(62) DEFAULT NULL COMMENT 'chức vụ, chức danh tại cấp uy',
  `Phu_Cap_Chuc_Vu` float DEFAULT NULL,
  `Ngay_Sinh` date DEFAULT NULL,
  `Noi_Sinh` varchar(254) DEFAULT NULL,
  `So_CMND` varchar(254) DEFAULT NULL,
  `Ngay_Cap_CMND` date DEFAULT NULL,
  `Noi_Cap_CMND` varchar(254) DEFAULT NULL,
  `Que_Quan` varchar(254) DEFAULT NULL,
  `Noi_O_Hien_Nay` varchar(254) DEFAULT NULL,
  `Dan_Toc` smallint(6) DEFAULT NULL,
  `Ton_Giao` smallint(6) DEFAULT NULL,
  `Đien_Thoai` varchar(254) DEFAULT NULL,
  `Thanh_Phan_Gia_Đinh_Xuat_Than` varchar(254) DEFAULT NULL,
  `Ngay_Tham_Gia_CM` date DEFAULT NULL,
  `Nghe_Nghiep_Truoc_Đo` varchar(254) DEFAULT NULL,
  `Ngay_Đuoc_Tuyen_Dung` date DEFAULT NULL,
  `Co_Quan_Tuyen_Dung` varchar(254) DEFAULT NULL,
  `Đia_Chi_Co_Quan_Tuyen_Dung` varchar(254) DEFAULT NULL,
  `Ngay_Vao_Đang` date DEFAULT NULL,
  `Ngay_Chinh_Thuc` date DEFAULT NULL,
  `Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi` varchar(254) DEFAULT NULL,
  `Ngay_Nhap_Ngu` date DEFAULT NULL,
  `Ngay_Xuat_Ngu` date DEFAULT NULL,
  `Quan_Ham_Chuc_Vu_Cao_Nhat` varchar(254) DEFAULT NULL,
  `Trinh_Đo_Hoc_Van` varchar(254) DEFAULT '12/12',
  `Hoc_Ham` varchar(254) DEFAULT NULL,
  `Cap_Đo_CTLL` decimal(4,2) DEFAULT NULL,
  `Cap_Đo_TĐCM` decimal(4,2) DEFAULT NULL,
  `Chuyen_Nganh` varchar(62) DEFAULT NULL,
  `Ngoai_Ngu` varchar(254) DEFAULT NULL,
  `Đac_Điem_Lich_Su` text,
  `Lam_Viec_Trong_Che_Đo_Cu` varchar(254) DEFAULT NULL,
  `Co_Than_Nhan_Nuoc_Ngoai` varchar(254) DEFAULT NULL,
  `Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai` varchar(254) DEFAULT NULL,
  `Cong_Tac_Chinh_Đang_Lam` varchar(254) DEFAULT NULL,
  `Danh_Hieu_Đuoc_Phong` varchar(254) DEFAULT NULL,
  `So_Truong_Cong_Tac` varchar(254) DEFAULT NULL,
  `Cong_Viec_Lam_Lau_Nhat` varchar(254) DEFAULT NULL,
  `Khen_Thuong` varchar(254) DEFAULT NULL,
  `Ky_Luat` varchar(254) DEFAULT NULL,
  `Tinh_Trang_Suc_Khoe` varchar(254) DEFAULT NULL,
  `Chieu_Cao` float DEFAULT NULL,
  `Can_Nang` float DEFAULT NULL,
  `Nhom_Mau` varchar(30) DEFAULT NULL,
  `Loai_Thuong_Binh` varchar(254) DEFAULT NULL,
  `Gia_Đinh_Liet_Sy` tinyint(1) DEFAULT NULL,
  `Luong_Thu_Nhap_Nam` bigint(20) unsigned DEFAULT '0',
  `Nguon_Thu_Khac` varchar(254) DEFAULT NULL,
  `Loai_Nha_Đuoc_Cap` varchar(62) DEFAULT NULL,
  `Dien_Tich_Nha_Đuoc_Cap` int(10) unsigned DEFAULT '0',
  `Loai_Nha_Tu_Xay` varchar(62) DEFAULT NULL,
  `Dien_Tich_Nha_Tu_Xay` int(10) unsigned DEFAULT '0',
  `Dien_Tich_Đat_O_Đuoc_Cap` int(10) unsigned DEFAULT '0',
  `Dien_Tich_Đat_O_Tu_Mua` int(10) unsigned DEFAULT '0',
  `Dien_Tich_Đat_San_Xuat` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`Ma_CB`),
  KEY `FK_co_TĐ_HV` (`Cap_Đo_TĐCM`),
  KEY `FK_co_TĐ_LLCT` (`Cap_Đo_CTLL`),
  KEY `FK_co_Dan_Toc` (`Dan_Toc`),
  KEY `FK_co_Ton_Giao` (`Ton_Giao`),
  CONSTRAINT `FK_co_Dan_Toc` FOREIGN KEY (`Dan_Toc`) REFERENCES `dan_toc` (`Ma_Dan_Toc`),
  CONSTRAINT `FK_co_Ly_Lich` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`),
  CONSTRAINT `FK_co_Ton_Giao` FOREIGN KEY (`Ton_Giao`) REFERENCES `ton_giao` (`Ma_Ton_Giao`),
  CONSTRAINT `FK_co_TĐ_HV` FOREIGN KEY (`Cap_Đo_TĐCM`) REFERENCES `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`),
  CONSTRAINT `FK_co_TĐ_LLCT` FOREIGN KEY (`Cap_Đo_CTLL`) REFERENCES `trinh_đo_ly_luan_chinh_tri` (`Cap_Đo_LLCT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `ly_lich`
--

/*!40000 ALTER TABLE `ly_lich` DISABLE KEYS */;
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('1','NTA-4311','Nguyễn Trác Thức','Không','0','Đảng bộ Trường ĐH CNTT','','Đảng Ủy viên','1.5','1980-11-20','TP. Hồ Chí Minh','352454537','1995-12-20','TP. Hồ Chí Minh','TP. Hồ Chí Minh','Bình Chánh, TP. Hồ Chí Minh','1','0','01234567890','Cán bộ',NULL,'Giảng viên','2013-12-02','Trường ĐH Khoa Học Tự Nhiên','Quận 1, TP. Hồ Chí Minh','2005-12-02','2006-12-02','2008-01-01',NULL,NULL,NULL,'12/12','Phó Giáo Sư','3.00','20.00',NULL,'Anh, Pháp',NULL,'Không','Không','Không','Giảng viên','Không','Tổ chức xây dựng Đoàn','Bí thư Đoàn trường','Bằng khen các cấp','Không','Tốt','1.7','80','O','Không','0','0',NULL,NULL,'0',NULL,'0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('2','NTA-1129','Lê Đức Thịnh','Không','0','Bí thư chi bộ Sinh viên','Không','3',NULL,'1989-01-01','Long An','435676357','2003-01-13','Long An','Long An','Quận Thủ Đức, TP. Hồ Chí Minh','1','0','01234567890','Viên chức',NULL,'Sinh viên','2010-01-14','Trường ĐH Công nghệ Thông tin','Thủ Đức, TP. Hồ Chí Minh','2005-01-21','2006-01-21','2009-11-11',NULL,NULL,NULL,'12/12',NULL,'2.00','16.00',NULL,'Anh',NULL,'Không','Không','Không','Giảng viên','Không','Công tác xây dựng Đoàn','Phó bí thư Đoàn trường','Giấy khen các cấp','Không','Tốt','1.7','60','A','không','0','0',NULL,NULL,'0',NULL,'0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('3','NTA-1322','Hoàng Anh Hùng','Không','0','Phó bí thư chi bộ','Không',NULL,NULL,'1923-02-03','Đồng Nai','012345678','2014-01-14','Đồng Nai','Thanh Hóa','Đồng Nai','3','0','01234567890','Nông dân',NULL,'Sinh viên','2014-01-08','Trường ĐH Công nghệ Thông tin','Thủ Đức, TP. Hồ Chí Minh','2014-01-08','2014-01-29',NULL,NULL,NULL,NULL,'12/12',NULL,'1.00','12.00',NULL,'Anh, Nhật',NULL,'Không','Không','Không','UV BTV','Không','Tuyên giáo','UV BTV','Giấy khen','Không','Tốt','1.7','65','O','Không','0','0',NULL,NULL,'0',NULL,'0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('4','NTA-1122','Trần Đình Thi','Không','0','Không','Không',NULL,NULL,'1992-02-25','An Giang','352039720','2007-03-15','An Giang','An Giang','Dĩ An, Bình Dương','2','0','01256745609','Viên chức',NULL,'Sinh viên','2014-01-21','Trường ĐH Công nghệ Thông tin','Thủ Đức, TP. Hồ Chí Minh',NULL,NULL,NULL,NULL,NULL,NULL,'12/12',NULL,'1.00','12.00',NULL,'Anh',NULL,'Không','Không','Không','Chủ tịch Hội Sinh viên','Không','Phong trào','Chủ tịch Hội Sinh viên','Bằng khen, Giấy khen','Không','Tốt','1.67','55','A','Không','0','0',NULL,NULL,'0',NULL,'0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('12','NTA-1122',NULL,'Tí Em','0','Không','Không','10',NULL,'1992-01-05','Đồng Tháp','123456789',NULL,'Tây Ninh','Đồng Tháp','TP. Hồ Chí Minh','1','2','0125674569','Nông dân',NULL,'Sinh viên','2014-02-04','UBND tỉnh Tây Ninh','Tây Ninh',NULL,NULL,NULL,NULL,NULL,NULL,'12/12','Không','1.00','12.00',NULL,'Anh',NULL,'(không làm)','(không có)','(không tham gia)','Ủy viên','không','CNTT',NULL,'Cán bộ đoàn giỏi cấp trường','(không)','bình thường','1.66',NULL,NULL,'1/5','1','200000000','trồng cao su: 100 triệu VNĐ/năm','nhà lá','50','Biệt thự','100','0','200','500');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('13','A123','Trần Phương Anh','Không','0','','',NULL,NULL,'1992-02-25','Sóc Trăng','352219534','0000-00-00','Sóc Trăng','An Giang','An Giang','1','0','12567455609','Công nhân viên chức','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'0000-00-00','0000-00-00','','0000-00-00','0000-00-00','','12/12','Không','0.00','12.00','','Anh, Hoa','','','','',NULL,'(không)','Phong trào','Sinh viên',NULL,NULL,'Tốt','1.67','50','O','Không','1','0',NULL,NULL,'0',NULL,'0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('14','A123','Trần Ngọc Anh','Không','0','','',NULL,NULL,'1992-02-25','Sóc Trăng','352219534','0000-00-00','Sóc Trăng','An Giang','An Giang','1','0','12567455609','Công nhân viên chức','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','Anh, Hoa','','','','',NULL,'(không)','Phong trào','Sinh viên',NULL,NULL,'Tốt','1.67','50','O','Không','1','0',NULL,NULL,'0',NULL,'0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('15','A123','Trần Hồng Anh','Không','0','','',NULL,NULL,'1992-02-25','Sóc Trăng','352219534','0000-00-00','Sóc Trăng','An Giang','An Giang','1','0','12567455609','Công nhân viên chức','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','Anh, Hoa','','','','',NULL,'(không)','Phong trào','Sinh viên',NULL,NULL,'Tốt','1.67','50','O','Không','1','0',NULL,NULL,'0',NULL,'0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('16','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('17','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('18','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('19','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('20','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('21','','Hoàng Ngọc Thiên','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('22','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('23','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('24','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('25','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('26','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('27','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('28','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('29','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','0000-00-00','','','','1','0','','','0000-00-00','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('30','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('31','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('32','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('33','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('34','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('35','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('36','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('37','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('38','','Hoàng Thanh Tâm','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('39','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('40','','Hoàng Ngọc Lý','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('41','','Hoàng Ngọc Hòa','','0','','',NULL,NULL,'2014-03-26','','','2014-03-26','','','','1','0','','','2014-03-26','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-26','2014-03-26','','2014-03-26','2014-03-26','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('42','A1-123-1245','Trương Đăng Khoa','','0','','',NULL,NULL,'1992-02-25','','352219588','2014-03-27','','','','1','0','','','2014-03-27','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-27','2014-03-27','','2014-03-27','2014-03-27','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('44','A43-43-44','Lưu Trọng Đạt','','0','','',NULL,NULL,'1994-03-19','','356645743','2014-03-14','Sóc Trăng','','','1','0','','','2014-03-28','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-28','2014-03-28','','2014-03-28','2014-03-28','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('45','','','','0','','',NULL,NULL,'2014-03-28','','','2014-03-28','','','','1','0','','','2014-03-28','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-28','2014-03-28','','2014-03-28','2014-03-28','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('46','','A1','','0','','',NULL,NULL,'1970-01-01','','A1','2014-03-28','','','','1','0','','','2014-03-28','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-28','2014-03-28','','2014-03-28','2014-03-28','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
INSERT INTO `ly_lich` (`Ma_CB`,`So_Hieu_CB`,`Ho_Ten_Khai_Sinh`,`Ten_Goi_Khac`,`Gioi_Tinh`,`Cap_Uy_Hien_Tai`,`Cap_Uy_Kiem`,`Chuc_Danh`,`Phu_Cap_Chuc_Vu`,`Ngay_Sinh`,`Noi_Sinh`,`So_CMND`,`Ngay_Cap_CMND`,`Noi_Cap_CMND`,`Que_Quan`,`Noi_O_Hien_Nay`,`Dan_Toc`,`Ton_Giao`,`Đien_Thoai`,`Thanh_Phan_Gia_Đinh_Xuat_Than`,`Ngay_Tham_Gia_CM`,`Nghe_Nghiep_Truoc_Đo`,`Ngay_Đuoc_Tuyen_Dung`,`Co_Quan_Tuyen_Dung`,`Đia_Chi_Co_Quan_Tuyen_Dung`,`Ngay_Vao_Đang`,`Ngay_Chinh_Thuc`,`Ngay_Tham_Gia_Cac_To_Chuc_Chinh_Tri_Xa_Hoi`,`Ngay_Nhap_Ngu`,`Ngay_Xuat_Ngu`,`Quan_Ham_Chuc_Vu_Cao_Nhat`,`Trinh_Đo_Hoc_Van`,`Hoc_Ham`,`Cap_Đo_CTLL`,`Cap_Đo_TĐCM`,`Chuyen_Nganh`,`Ngoai_Ngu`,`Đac_Điem_Lich_Su`,`Lam_Viec_Trong_Che_Đo_Cu`,`Co_Than_Nhan_Nuoc_Ngoai`,`Tham_Gia_Cac_To_Chuc_Nuoc_Ngoai`,`Cong_Tac_Chinh_Đang_Lam`,`Danh_Hieu_Đuoc_Phong`,`So_Truong_Cong_Tac`,`Cong_Viec_Lam_Lau_Nhat`,`Khen_Thuong`,`Ky_Luat`,`Tinh_Trang_Suc_Khoe`,`Chieu_Cao`,`Can_Nang`,`Nhom_Mau`,`Loai_Thuong_Binh`,`Gia_Đinh_Liet_Sy`,`Luong_Thu_Nhap_Nam`,`Nguon_Thu_Khac`,`Loai_Nha_Đuoc_Cap`,`Dien_Tich_Nha_Đuoc_Cap`,`Loai_Nha_Tu_Xay`,`Dien_Tich_Nha_Tu_Xay`,`Dien_Tich_Đat_O_Đuoc_Cap`,`Dien_Tich_Đat_O_Tu_Mua`,`Dien_Tich_Đat_San_Xuat`) VALUES ('47','','A2','','0','','',NULL,NULL,'1970-01-01','','A2','2014-03-28','','','','1','0','','','2014-03-28','',NULL,'Thành Đoàn TPHCM',NULL,'2014-03-28','2014-03-28','','2014-03-28','2014-03-28','','12/12','Không','0.00','12.00','','','','','','',NULL,'','','',NULL,NULL,'','0','0','O','Không','0','0','','','0','','0','0','0','0');
/*!40000 ALTER TABLE `ly_lich` ENABLE KEYS */;


--
-- Create Table `module`
--

DROP TABLE IF EXISTS `module`;
CREATE TABLE `module` (
  `Module_Name` varchar(32) NOT NULL,
  `Module_Display_Name` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Module_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `module`
--

/*!40000 ALTER TABLE `module` DISABLE KEYS */;
/*!40000 ALTER TABLE `module` ENABLE KEYS */;


--
-- Create Table `muc_đo_hoan_thanh`
--

DROP TABLE IF EXISTS `muc_đo_hoan_thanh`;
CREATE TABLE `muc_đo_hoan_thanh` (
  `Ma_MĐHT` tinyint(4) NOT NULL AUTO_INCREMENT,
  `Ten_MĐHT` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_MĐHT`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Data for Table `muc_đo_hoan_thanh`
--

/*!40000 ALTER TABLE `muc_đo_hoan_thanh` DISABLE KEYS */;
INSERT INTO `muc_đo_hoan_thanh` (`Ma_MĐHT`,`Ten_MĐHT`) VALUES ('1','Hoàn thành xuất sắc chức trách, nhiệm vụ');
INSERT INTO `muc_đo_hoan_thanh` (`Ma_MĐHT`,`Ten_MĐHT`) VALUES ('2','Hoàn thành tốt chức trách, nhiệm vụ');
INSERT INTO `muc_đo_hoan_thanh` (`Ma_MĐHT`,`Ten_MĐHT`) VALUES ('3','Hoàn thành chức trách, nhiệm vụ');
INSERT INTO `muc_đo_hoan_thanh` (`Ma_MĐHT`,`Ten_MĐHT`) VALUES ('4','Chưa hoàn thành chức trách, nhiệm vụ');
/*!40000 ALTER TABLE `muc_đo_hoan_thanh` ENABLE KEYS */;


--
-- Create Table `muc_sua_đoi`
--

DROP TABLE IF EXISTS `muc_sua_đoi`;
CREATE TABLE `muc_sua_đoi` (
  `Ma_Yeu_Cau` bigint(20) unsigned NOT NULL,
  `Ten_Cot_Thay_Đoi` varchar(254) NOT NULL,
  `Gia_Tri_Thay_Đoi` varchar(254) DEFAULT NULL,
  `Ten_Hien_Thi` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_Yeu_Cau`,`Ten_Cot_Thay_Đoi`),
  CONSTRAINT `FK_muc_thay_đoi_cua_yeu_cau` FOREIGN KEY (`Ma_Yeu_Cau`) REFERENCES `yeu_cau_thay_đoi_tt_cb` (`Ma_Yeu_Cau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `muc_sua_đoi`
--

/*!40000 ALTER TABLE `muc_sua_đoi` DISABLE KEYS */;
/*!40000 ALTER TABLE `muc_sua_đoi` ENABLE KEYS */;


--
-- Create Table `muc_thuong_theo_dien`
--

DROP TABLE IF EXISTS `muc_thuong_theo_dien`;
CREATE TABLE `muc_thuong_theo_dien` (
  `Ma_Dien` smallint(6) NOT NULL,
  `Ma_DS_Khen_Thuong` int(10) unsigned NOT NULL,
  `Muc_Thuong` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Ma_Dien`,`Ma_DS_Khen_Thuong`),
  KEY `FK_kq_xet` (`Ma_DS_Khen_Thuong`),
  CONSTRAINT `FK_dien_nhan_thuong` FOREIGN KEY (`Ma_Dien`) REFERENCES `dien_khen_thuong` (`Ma_Dien`),
  CONSTRAINT `FK_kq_xet` FOREIGN KEY (`Ma_DS_Khen_Thuong`) REFERENCES `kq_xet_thi_đua` (`Ma_DS_Khen_Thuong`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `muc_thuong_theo_dien`
--

/*!40000 ALTER TABLE `muc_thuong_theo_dien` DISABLE KEYS */;
/*!40000 ALTER TABLE `muc_thuong_theo_dien` ENABLE KEYS */;


--
-- Create Table `ngach_luong`
--

DROP TABLE IF EXISTS `ngach_luong`;
CREATE TABLE `ngach_luong` (
  `Ma_So_Ngach` varchar(32) NOT NULL,
  `Ky_Hieu_Ngach` varchar(32) DEFAULT NULL,
  `Ten_Ngach` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_So_Ngach`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `ngach_luong`
--

/*!40000 ALTER TABLE `ngach_luong` DISABLE KEYS */;
INSERT INTO `ngach_luong` (`Ma_So_Ngach`,`Ky_Hieu_Ngach`,`Ten_Ngach`) VALUES ('00000',NULL,'(không hưởng lương)');
INSERT INTO `ngach_luong` (`Ma_So_Ngach`,`Ky_Hieu_Ngach`,`Ten_Ngach`) VALUES ('01001','','Chuyên Viên Cao Cấp');
INSERT INTO `ngach_luong` (`Ma_So_Ngach`,`Ky_Hieu_Ngach`,`Ten_Ngach`) VALUES ('01003',NULL,'Chuyên Viên');
INSERT INTO `ngach_luong` (`Ma_So_Ngach`,`Ky_Hieu_Ngach`,`Ten_Ngach`) VALUES ('01004','','Cán Sự');
/*!40000 ALTER TABLE `ngach_luong` ENABLE KEYS */;


--
-- Create Table `ngoai_ngu`
--

DROP TABLE IF EXISTS `ngoai_ngu`;
CREATE TABLE `ngoai_ngu` (
  `Ma_Ngoai_Ngu` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Ten_Ngoai_Ngu` varchar(63) DEFAULT NULL,
  PRIMARY KEY (`Ma_Ngoai_Ngu`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Data for Table `ngoai_ngu`
--

/*!40000 ALTER TABLE `ngoai_ngu` DISABLE KEYS */;
INSERT INTO `ngoai_ngu` (`Ma_Ngoai_Ngu`,`Ten_Ngoai_Ngu`) VALUES ('0','(không)');
INSERT INTO `ngoai_ngu` (`Ma_Ngoai_Ngu`,`Ten_Ngoai_Ngu`) VALUES ('1','Anh');
INSERT INTO `ngoai_ngu` (`Ma_Ngoai_Ngu`,`Ten_Ngoai_Ngu`) VALUES ('2','Pháp');
INSERT INTO `ngoai_ngu` (`Ma_Ngoai_Ngu`,`Ten_Ngoai_Ngu`) VALUES ('3','Nhật');
INSERT INTO `ngoai_ngu` (`Ma_Ngoai_Ngu`,`Ten_Ngoai_Ngu`) VALUES ('4','Hàn Quốc');
INSERT INTO `ngoai_ngu` (`Ma_Ngoai_Ngu`,`Ten_Ngoai_Ngu`) VALUES ('5','Hoa');
INSERT INTO `ngoai_ngu` (`Ma_Ngoai_Ngu`,`Ten_Ngoai_Ngu`) VALUES ('6','Thái');
/*!40000 ALTER TABLE `ngoai_ngu` ENABLE KEYS */;


--
-- Create Table `privilege`
--

DROP TABLE IF EXISTS `privilege`;
CREATE TABLE `privilege` (
  `Privilege_Name` varchar(32) NOT NULL,
  `Controller_Name` varchar(32) DEFAULT NULL,
  `Privilege_Display_Name` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Privilege_Name`),
  KEY `FK_of_controller` (`Controller_Name`),
  CONSTRAINT `FK_of_controller` FOREIGN KEY (`Controller_Name`) REFERENCES `controller` (`Controller_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `privilege`
--

/*!40000 ALTER TABLE `privilege` DISABLE KEYS */;
/*!40000 ALTER TABLE `privilege` ENABLE KEYS */;


--
-- Create Table `profile`
--

DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile` (
  `UserID` int(11) NOT NULL,
  `Avatar_URL` varchar(254) DEFAULT NULL,
  `Surname` varchar(254) DEFAULT NULL,
  `Firstname` varchar(254) DEFAULT NULL,
  `Email` varchar(254) DEFAULT NULL,
  `Description` varchar(254) DEFAULT NULL,
  `Phone` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`UserID`),
  CONSTRAINT `FK_of_user` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `profile`
--

/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;


--
-- Create Table `qua_trinh_cong_tac`
--

DROP TABLE IF EXISTS `qua_trinh_cong_tac`;
CREATE TABLE `qua_trinh_cong_tac` (
  `Ma_CB` int(11) NOT NULL,
  `Ma_QTCT` bigint(20) NOT NULL AUTO_INCREMENT,
  `Tu_Ngay` date DEFAULT NULL,
  `Đen_Ngay` date DEFAULT NULL,
  `So_Luoc` varchar(254) DEFAULT NULL,
  `Chuc_Danh` varchar(62) DEFAULT NULL,
  `Chuc_Vu` varchar(62) DEFAULT NULL,
  `Đon_Vi_Cong_Tac` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_QTCT`,`Ma_CB`),
  KEY `Ma_CB` (`Ma_CB`),
  CONSTRAINT `qua_trinh_cong_tac_ibfk_1` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `qua_trinh_cong_tac`
--

/*!40000 ALTER TABLE `qua_trinh_cong_tac` DISABLE KEYS */;
INSERT INTO `qua_trinh_cong_tac` (`Ma_CB`,`Ma_QTCT`,`Tu_Ngay`,`Đen_Ngay`,`So_Luoc`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`) VALUES ('12','1','2014-01-01','2014-01-03','Ủy viên','','Ủy Viên','ĐH CNTT');
INSERT INTO `qua_trinh_cong_tac` (`Ma_CB`,`Ma_QTCT`,`Tu_Ngay`,`Đen_Ngay`,`So_Luoc`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`) VALUES ('19','2','2014-03-05','2014-03-06','abc',NULL,NULL,NULL);
INSERT INTO `qua_trinh_cong_tac` (`Ma_CB`,`Ma_QTCT`,`Tu_Ngay`,`Đen_Ngay`,`So_Luoc`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`) VALUES ('19','3','2014-03-08','2014-03-09','dsf',NULL,NULL,NULL);
INSERT INTO `qua_trinh_cong_tac` (`Ma_CB`,`Ma_QTCT`,`Tu_Ngay`,`Đen_Ngay`,`So_Luoc`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`) VALUES ('19','4','2014-03-17','2014-03-27','snj',NULL,NULL,NULL);
INSERT INTO `qua_trinh_cong_tac` (`Ma_CB`,`Ma_QTCT`,`Tu_Ngay`,`Đen_Ngay`,`So_Luoc`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`) VALUES ('23','5','2014-03-12','1970-01-01','Thành Đoàn',NULL,NULL,NULL);
INSERT INTO `qua_trinh_cong_tac` (`Ma_CB`,`Ma_QTCT`,`Tu_Ngay`,`Đen_Ngay`,`So_Luoc`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`) VALUES ('23','6','2014-03-27','1970-01-01','Thành Đoàn',NULL,NULL,NULL);
/*!40000 ALTER TABLE `qua_trinh_cong_tac` ENABLE KEYS */;


--
-- Create Table `qua_trinh_luong`
--

DROP TABLE IF EXISTS `qua_trinh_luong`;
CREATE TABLE `qua_trinh_luong` (
  `Ma_CB` int(11) NOT NULL,
  `Thoi_Gian_Nang_Luong` date NOT NULL DEFAULT '0001-01-01',
  `Ma_So_Ngach` varchar(254) DEFAULT NULL,
  `Bac_Luong` varchar(32) DEFAULT NULL,
  `He_So_Luong` float DEFAULT NULL,
  `Phu_Cap_Vuot_Khung` float DEFAULT NULL,
  `He_So_Phu_Cap` float DEFAULT NULL,
  `Muc_Luong_Khoang` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Ma_CB`,`Thoi_Gian_Nang_Luong`),
  KEY `FK_co_Ngach` (`Ma_So_Ngach`),
  KEY `INDEX_NgayNangLuong` (`Thoi_Gian_Nang_Luong`),
  KEY `INDEX_MaCanBO` (`Ma_CB`),
  CONSTRAINT `FK_co_Ngach` FOREIGN KEY (`Ma_So_Ngach`) REFERENCES `ngach_luong` (`Ma_So_Ngach`),
  CONSTRAINT `FK_luong_cua_can_bo` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `qua_trinh_luong`
--

/*!40000 ALTER TABLE `qua_trinh_luong` DISABLE KEYS */;
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('1','2003-03-02','01001','5','5.1','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('1','2009-02-02','01001','6','6.1','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('1','2014-03-28','01001','6','6.2','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('2','2014-03-11','01003','4','4.3','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('3','2008-03-15','01004','4','3.4','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('4','2014-03-28','01001','4','3.4','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('12','2013-03-11','01001','1','1.1','10','1','1300000');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('12','2014-03-11','01001','4','4.3','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('12','2014-03-12','01004','4','4.9','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('12','2014-03-13','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('13','2014-03-14','01004','1','1','1','1','1300000');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('14','2014-03-13','01004','1','1','1','1','1300000');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('14','2014-03-30','00000','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('15','2014-03-12','01004','1','1','1','1','1300000');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('16','2014-03-05','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('17','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('18','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('19','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('20','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('21','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('22','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('23','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('24','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('25','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('26','2014-03-14','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('28','2014-03-11','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('29','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('30','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('31','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('32','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('33','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('34','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('35','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('36','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('37','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('38','2014-03-20','01001','4','3.2',NULL,'0',NULL);
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('38','2014-03-29','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('39','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('40','2003-01-01','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('40','2014-03-12','01001','4','3.2','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('41','2014-03-05','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('41','2014-03-12','01001','4','3.2','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('44','2014-03-28','01004','2','1.4','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('45','2014-03-28','01001','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('46','2014-03-28','00000','','0','0','0','0');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('47','2014-03-12','00000','4','3.2','0.5','1.1','2000');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('47','2014-03-13','00000','5','4.4','0.6','1.2','3000');
INSERT INTO `qua_trinh_luong` (`Ma_CB`,`Thoi_Gian_Nang_Luong`,`Ma_So_Ngach`,`Bac_Luong`,`He_So_Luong`,`Phu_Cap_Vuot_Khung`,`He_So_Phu_Cap`,`Muc_Luong_Khoang`) VALUES ('47','2014-03-28','00000','','0','0','0','0');
/*!40000 ALTER TABLE `qua_trinh_luong` ENABLE KEYS */;


--
-- Create Table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `Role_Name` varchar(32) NOT NULL,
  `Role_Display_Name` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Role_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `role`
--

/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`Role_Name`,`Role_Display_Name`) VALUES ('admin','Quản trị cao cấp');
INSERT INTO `role` (`Role_Name`,`Role_Display_Name`) VALUES ('cadre','Cán Bộ');
INSERT INTO `role` (`Role_Name`,`Role_Display_Name`) VALUES ('manager','Cán Bộ Quản lý');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;


--
-- Create Table `role_privilege_relation`
--

DROP TABLE IF EXISTS `role_privilege_relation`;
CREATE TABLE `role_privilege_relation` (
  `Role_Name` varchar(32) NOT NULL,
  `Privilege_Name` varchar(32) NOT NULL,
  `isAllowed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`Role_Name`,`Privilege_Name`),
  KEY `FK_for_role` (`Privilege_Name`),
  CONSTRAINT `FK_for_role` FOREIGN KEY (`Privilege_Name`) REFERENCES `privilege` (`Privilege_Name`),
  CONSTRAINT `FK_have_privilege` FOREIGN KEY (`Role_Name`) REFERENCES `role` (`Role_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `role_privilege_relation`
--

/*!40000 ALTER TABLE `role_privilege_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_privilege_relation` ENABLE KEYS */;


--
-- Create Table `status`
--

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `Status_Code` tinyint(4) NOT NULL,
  `Status_Name` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Status_Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `status`
--

/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` (`Status_Code`,`Status_Name`) VALUES ('-1','blocked');
INSERT INTO `status` (`Status_Code`,`Status_Name`) VALUES ('0','unconfirmed');
INSERT INTO `status` (`Status_Code`,`Status_Name`) VALUES ('1','actived');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;


--
-- Create Table `thanh_vien_gia_đinh`
--

DROP TABLE IF EXISTS `thanh_vien_gia_đinh`;
CREATE TABLE `thanh_vien_gia_đinh` (
  `Ma_Quan_He` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Ma_CB` int(11) NOT NULL,
  `Ben_Vo` tinyint(1) NOT NULL,
  `Quan_He` varchar(62) NOT NULL,
  `Ho_Ten` varchar(62) DEFAULT NULL,
  `Nam_Sinh` date DEFAULT NULL,
  `Thong_Tin_So_Luoc` text,
  `Que_Quan` varchar(254) DEFAULT NULL,
  `Nghe_Nghiep` varchar(254) DEFAULT NULL,
  `Chuc_Danh` varchar(254) DEFAULT NULL,
  `Chuc_Vu` varchar(254) DEFAULT NULL,
  `Đon_Vi_Cong_Tac` varchar(254) DEFAULT NULL,
  `Hoc_Tap` varchar(254) DEFAULT NULL,
  `Noi_O` varchar(254) DEFAULT NULL,
  `Thanh_Vien_Cac_To_Chuc` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_Quan_He`,`Ma_CB`),
  KEY `Ben_Vo` (`Ben_Vo`),
  KEY `Ma_CB` (`Ma_CB`),
  KEY `Ma_Quan_He` (`Ma_Quan_He`),
  CONSTRAINT `FK_cua_can_bo` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Data for Table `thanh_vien_gia_đinh`
--

/*!40000 ALTER TABLE `thanh_vien_gia_đinh` DISABLE KEYS */;
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('1','12','0','Cha','Nguuyễn Anh Tuấn','1988-02-03',NULL,'Tây Ninh','Thương Gia','không','không','nhà vợ\r\n','cao học','Tây Ninh','không');
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('2','12','1','Cha','Lê Long','1980-03-13','bình thường',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('3','30','0','','','2014-03-26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('4','30','0','','','2014-03-26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('5','31','0','','','2014-03-26','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('6','31','0','','','2014-03-26','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('7','32','1','Cha','','2014-03-26','a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `thanh_vien_gia_đinh` (`Ma_Quan_He`,`Ma_CB`,`Ben_Vo`,`Quan_He`,`Ho_Ten`,`Nam_Sinh`,`Thong_Tin_So_Luoc`,`Que_Quan`,`Nghe_Nghiep`,`Chuc_Danh`,`Chuc_Vu`,`Đon_Vi_Cong_Tac`,`Hoc_Tap`,`Noi_O`,`Thanh_Vien_Cac_To_Chuc`) VALUES ('8','32','1','Mẹ','','2014-03-26','b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `thanh_vien_gia_đinh` ENABLE KEYS */;


--
-- Create Table `thong_tin_tham_gia_ban`
--

DROP TABLE IF EXISTS `thong_tin_tham_gia_ban`;
CREATE TABLE `thong_tin_tham_gia_ban` (
  `Ma_CB` int(11) NOT NULL,
  `Ma_Ban` int(11) NOT NULL,
  `Ngay_Gia_Nhap` date NOT NULL,
  `Ngay_Roi_Khoi` date DEFAULT NULL,
  `Ly_Do_Chuyen_Đen` varchar(254) DEFAULT NULL,
  `Ma_CV` smallint(5) unsigned DEFAULT NULL,
  `La_Cong_Tac_Chinh` tinyint(4) NOT NULL DEFAULT '1',
  `STT_To` tinyint(4) DEFAULT NULL,
  `Ma_Ban_Truoc_Đo` int(11) DEFAULT NULL,
  `Ngay_GN_Ban_Truoc_Đo` date DEFAULT NULL,
  `Trang_Thai` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1-Đang công tác, 0-đã chuyển đi',
  PRIMARY KEY (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`),
  KEY `FK_Ban_Đi` (`Ma_CB`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`),
  KEY `FK_cv_tai_ban` (`Ma_CV`),
  KEY `FK_to_cong_tac_cua_CB_tai_ban` (`Ma_Ban`,`STT_To`),
  KEY `La_Cong_Tac_Chinh` (`La_Cong_Tac_Chinh`),
  KEY `Ngay_Roi_Khoi` (`Ngay_Roi_Khoi`),
  KEY `Ma_Ban` (`Ma_Ban`),
  KEY `Ngay_Gia_Nhap` (`Ngay_Gia_Nhap`),
  KEY `Ma_Ban__NgayRK` (`Ma_Ban`,`Ngay_Roi_Khoi`),
  KEY `Ma_CB___NgayRK__Ma_CV` (`Ma_CB`,`Ngay_Roi_Khoi`,`Ma_CV`),
  KEY `Trang_Thai` (`Trang_Thai`),
  CONSTRAINT `FK_Ban_Tham_Gia` FOREIGN KEY (`Ma_Ban`) REFERENCES `ban` (`Ma_Ban`),
  CONSTRAINT `FK_Ban_Đi` FOREIGN KEY (`Ma_CB`, `Ma_Ban_Truoc_Đo`, `Ngay_GN_Ban_Truoc_Đo`) REFERENCES `thong_tin_tham_gia_ban` (`Ma_CB`, `Ma_Ban`, `Ngay_Gia_Nhap`),
  CONSTRAINT `FK_Can_Bo_Tai_Ban` FOREIGN KEY (`Ma_CB`) REFERENCES `can_bo` (`Ma_Can_Bo`),
  CONSTRAINT `FK_cv_tai_ban` FOREIGN KEY (`Ma_CV`) REFERENCES `chuc_vu` (`Ma_Chuc_Vu`),
  CONSTRAINT `FK_to_cong_tac_cua_CB_tai_ban` FOREIGN KEY (`Ma_Ban`, `STT_To`) REFERENCES `to_cong_tac` (`Ma_Ban`, `STT_To`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `thong_tin_tham_gia_ban`
--

/*!40000 ALTER TABLE `thong_tin_tham_gia_ban` DISABLE KEYS */;
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('1','25','2014-03-28',NULL,' chuyển chổ ở','15','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('1','26','2014-01-07','2014-03-07',NULL,'1','0',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('1','28','2014-03-28',NULL,' bổ nhiệm','5','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('1','56','2014-03-20',NULL,NULL,'1','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('1','56','2014-03-28',NULL,' ','0','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('1','62','2014-03-31',NULL,NULL,'13','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('2','56','2013-01-01',NULL,NULL,'2','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('3','25','2014-03-25',NULL,' ','15','0',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('3','27','1970-01-01','2014-03-01',NULL,'5','0',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('3','28','2014-03-21',NULL,NULL,'5','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('3','62','2014-03-31',NULL,NULL,'10','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('4','56','2010-01-06',NULL,NULL,'5','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('12','56','2014-03-20',NULL,NULL,'7','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('13','58','2014-03-28',NULL,NULL,'1','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('16','57','2014-03-28',NULL,NULL,'1','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('16','58','2014-03-28',NULL,NULL,'3','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('42','60','2014-03-31',NULL,NULL,'1','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('42','61','2014-03-31',NULL,NULL,'1','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('44','60','2014-03-31',NULL,NULL,'3','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('44','61','2014-03-31',NULL,NULL,'3','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('46','59','2014-03-31',NULL,NULL,'1','1',NULL,NULL,NULL,'1');
INSERT INTO `thong_tin_tham_gia_ban` (`Ma_CB`,`Ma_Ban`,`Ngay_Gia_Nhap`,`Ngay_Roi_Khoi`,`Ly_Do_Chuyen_Đen`,`Ma_CV`,`La_Cong_Tac_Chinh`,`STT_To`,`Ma_Ban_Truoc_Đo`,`Ngay_GN_Ban_Truoc_Đo`,`Trang_Thai`) VALUES ('47','59','2014-03-31',NULL,NULL,'0','1',NULL,NULL,NULL,'1');
/*!40000 ALTER TABLE `thong_tin_tham_gia_ban` ENABLE KEYS */;


--
-- Create Table `to_cong_tac`
--

DROP TABLE IF EXISTS `to_cong_tac`;
CREATE TABLE `to_cong_tac` (
  `Ma_Ban` int(11) NOT NULL,
  `STT_To` tinyint(4) NOT NULL,
  `Ten_To` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`Ma_Ban`,`STT_To`),
  CONSTRAINT `FK_ban_truc_thuoc` FOREIGN KEY (`Ma_Ban`) REFERENCES `ban` (`Ma_Ban`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `to_cong_tac`
--

/*!40000 ALTER TABLE `to_cong_tac` DISABLE KEYS */;
/*!40000 ALTER TABLE `to_cong_tac` ENABLE KEYS */;


--
-- Create Table `ton_giao`
--

DROP TABLE IF EXISTS `ton_giao`;
CREATE TABLE `ton_giao` (
  `Ma_Ton_Giao` smallint(6) NOT NULL AUTO_INCREMENT,
  `Ten_Ton_Giao` varchar(62) DEFAULT NULL,
  PRIMARY KEY (`Ma_Ton_Giao`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

--
-- Data for Table `ton_giao`
--

/*!40000 ALTER TABLE `ton_giao` DISABLE KEYS */;
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('0','(không)');
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('1','(khác)');
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('2','Phật Giáo');
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('3','Cao Đài');
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('4','Hòa Hảo');
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('5','Thiên Chúa');
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('6','Ấn Độ Giáo');
INSERT INTO `ton_giao` (`Ma_Ton_Giao`,`Ten_Ton_Giao`) VALUES ('7','Hiếu Nghĩa');
/*!40000 ALTER TABLE `ton_giao` ENABLE KEYS */;


--
-- Create Table `trinh_đo_chuyen_mon`
--

DROP TABLE IF EXISTS `trinh_đo_chuyen_mon`;
CREATE TABLE `trinh_đo_chuyen_mon` (
  `Cap_Đo_TĐCM` decimal(4,2) NOT NULL DEFAULT '0.00',
  `Ten_TĐCM` varchar(254) DEFAULT NULL,
  `Viet_Tat_TĐCM` varchar(8) NOT NULL,
  PRIMARY KEY (`Cap_Đo_TĐCM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `trinh_đo_chuyen_mon`
--

/*!40000 ALTER TABLE `trinh_đo_chuyen_mon` DISABLE KEYS */;
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('12.00','(chưa có bằng CM)','');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('14.00','Trung cấp','TC');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('14.50','TC Chuyên Nghiệp','TCCN');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('15.00','Cao đẳng','CĐ');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('16.00','Cử nhân','CN ĐH');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('16.50','Kỹ sư','KS ĐH');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('18.00','Thạc Sỹ','ThS');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('20.00','Tiến Sỹ','TS');
INSERT INTO `trinh_đo_chuyen_mon` (`Cap_Đo_TĐCM`,`Ten_TĐCM`,`Viet_Tat_TĐCM`) VALUES ('22.00','Tiến Sỹ Khoa Học','TSKH');
/*!40000 ALTER TABLE `trinh_đo_chuyen_mon` ENABLE KEYS */;


--
-- Create Table `trinh_đo_ly_luan_chinh_tri`
--

DROP TABLE IF EXISTS `trinh_đo_ly_luan_chinh_tri`;
CREATE TABLE `trinh_đo_ly_luan_chinh_tri` (
  `Cap_Đo_LLCT` decimal(4,2) NOT NULL DEFAULT '0.00',
  `Ten_CTLL` varchar(254) DEFAULT NULL,
  `Viet_Tat_CTLL` varchar(32) NOT NULL,
  PRIMARY KEY (`Cap_Đo_LLCT`),
  KEY `cap_do_lltt` (`Cap_Đo_LLCT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `trinh_đo_ly_luan_chinh_tri`
--

/*!40000 ALTER TABLE `trinh_đo_ly_luan_chinh_tri` DISABLE KEYS */;
INSERT INTO `trinh_đo_ly_luan_chinh_tri` (`Cap_Đo_LLCT`,`Ten_CTLL`,`Viet_Tat_CTLL`) VALUES ('0.00','(chưa có)','');
INSERT INTO `trinh_đo_ly_luan_chinh_tri` (`Cap_Đo_LLCT`,`Ten_CTLL`,`Viet_Tat_CTLL`) VALUES ('1.00','Sơ cấp','SC');
INSERT INTO `trinh_đo_ly_luan_chinh_tri` (`Cap_Đo_LLCT`,`Ten_CTLL`,`Viet_Tat_CTLL`) VALUES ('2.00','Trung cấp','TC');
INSERT INTO `trinh_đo_ly_luan_chinh_tri` (`Cap_Đo_LLCT`,`Ten_CTLL`,`Viet_Tat_CTLL`) VALUES ('3.00','Cao cấp','CC');
/*!40000 ALTER TABLE `trinh_đo_ly_luan_chinh_tri` ENABLE KEYS */;


--
-- Create Table `tt_tai_đon_vi`
--

DROP TABLE IF EXISTS `tt_tai_đon_vi`;
CREATE TABLE `tt_tai_đon_vi` (
  `NgayDen` datetime DEFAULT NULL,
  `LidoChuyenĐen` varchar(254) DEFAULT NULL,
  `HoSoXacNhan` varchar(254) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `tt_tai_đon_vi`
--

/*!40000 ALTER TABLE `tt_tai_đon_vi` DISABLE KEYS */;
/*!40000 ALTER TABLE `tt_tai_đon_vi` ENABLE KEYS */;


--
-- Create Table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(254) NOT NULL,
  `Password` varchar(254) DEFAULT NULL,
  `Identifier_Info` int(11) DEFAULT NULL,
  `Status_Code` tinyint(4) DEFAULT '1',
  `Role_Name` varchar(32) DEFAULT NULL,
  `Password_Key` varchar(254) NOT NULL DEFAULT 'dk',
  PRIMARY KEY (`UserID`),
  UNIQUE KEY `Username` (`Username`),
  KEY `FK_have_role` (`Role_Name`),
  KEY `FK_have_status` (`Status_Code`),
  KEY `Identifier_Info` (`Identifier_Info`),
  CONSTRAINT `FK_have_role` FOREIGN KEY (`Role_Name`) REFERENCES `role` (`Role_Name`),
  CONSTRAINT `FK_have_status` FOREIGN KEY (`Status_Code`) REFERENCES `status` (`Status_Code`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

--
-- Data for Table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('1','admin','66579284dd25f62cde52b036108c4bd6','1','1','admin','dk');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('10','manager','7cee25e6e3661fc12b09ebfb1e801c87','3','1','manager','30/03/2014 01:03:59:0359');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('15','dangkhoa','337ab2818447d7027e59d462317c3105',NULL,'1','manager','31/12/2013 10:12:16:1216');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('16','phobithu','8880d22d7f12eeabe27802c41532315e','2','1','admin','31/12/2013 10:12:03:1203');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('17','dinhthi','1000c73b2aaf80ac21bda4784150e1a7','4','1','cadre','12/03/2014 10:03:34:0334');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('18','nguyentuananh','a73b90b4555d62137a448d0a66743116','12','1','cadre','31/12/2013 10:12:47:1247');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('19','xuanthu','729419e53834c5319a68c2f789385ac3','4','1','cadre','30/03/2014 07:03:17:0317');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('20','hoanganhhung','0031755bcdd0a3a7a89fad4e30a134b0','3','1','cadre','12/03/2014 07:03:37:0337');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('21','tracthuc','3d2b3d90a84f169f4b1c1420c8a33117','1','1','cadre','21/03/2014 07:03:15:0315');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('22','thinhle','e260afb31fc41128db21a61132e8e33e','2','1','cadre','25/03/2014 09:03:51:0351');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('23','352219588','eb80fb66106d920a01e088a6c70776ce','42','1','cadre','27/03/2014 06:03:47:0347');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('24','356645743','df77d1e81a7013b5cbf32e14b1a9cd62','44','1','cadre','28/03/2014 06:03:51:0351');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('25','','1d30676dacb1a06036134ea99d42fe83','45','1','cadre','28/03/2014 06:03:50:0350');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('26','A1','5c71dceba1a0cbc9a7345c94b2ca3ef0','46','1','cadre','28/03/2014 07:03:40:0340');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('27','A2','ccfcf510c91ce56fdd8fd5b95c857617','47','1','cadre','28/03/2014 07:03:24:0324');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('29','test2','3ee9e75860745934358fec45d5b67573','0','1','admin','30/03/2014 08:03:11:0311');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('30','test3','fb9f589248fb3daeaeddf5839774ebe6',NULL,'1','admin','30/03/2014 08:03:05:0305');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('33','test4','6e4c5a143f2f967da1594cc8f4c8bcac',NULL,'1','manager','30/03/2014 08:03:40:0340');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('34','test5','fb9f589248fb3daeaeddf5839774ebe6','12','1','cadre','30/03/2014 08:03:05:0305');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('36','test6','852a5ec62e888efe2216e87d6bf675ce',NULL,'1',NULL,'30/03/2014 09:03:23:0323');
INSERT INTO `user` (`UserID`,`Username`,`Password`,`Identifier_Info`,`Status_Code`,`Role_Name`,`Password_Key`) VALUES ('38','test7','a5f98eb8242a0cb8f959db1efea4a709',NULL,'-1','cadre','30/03/2014 09:03:44:0344');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;


--
-- Create Table `user_log`
--

DROP TABLE IF EXISTS `user_log`;
CREATE TABLE `user_log` (
  `Thoi_Gian` datetime NOT NULL,
  `Ma_User_Thuc_Hien` int(11) NOT NULL,
  `Ma_CB_Thuc_Hien` int(11) NOT NULL,
  `Chuc_Nang` varchar(254) DEFAULT NULL,
  `Noi_Dung` text,
  PRIMARY KEY (`Thoi_Gian`,`Ma_User_Thuc_Hien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `user_log`
--

/*!40000 ALTER TABLE `user_log` DISABLE KEYS */;
INSERT INTO `user_log` (`Thoi_Gian`,`Ma_User_Thuc_Hien`,`Ma_CB_Thuc_Hien`,`Chuc_Nang`,`Noi_Dung`) VALUES ('2014-03-21 04:04:11','10','3','Sửa lý lịch','Sửa lý lịch cho cán bộ Trần Đình Thi - MS: 000');
INSERT INTO `user_log` (`Thoi_Gian`,`Ma_User_Thuc_Hien`,`Ma_CB_Thuc_Hien`,`Chuc_Nang`,`Noi_Dung`) VALUES ('2014-03-21 06:04:11','10','3','Nâng lương','Nâng lương cho cán bộ Hoàng Anh Hùng');
INSERT INTO `user_log` (`Thoi_Gian`,`Ma_User_Thuc_Hien`,`Ma_CB_Thuc_Hien`,`Chuc_Nang`,`Noi_Dung`) VALUES ('2014-03-25 04:04:11','10','3','Sửa quá trình đi nước ngoài','Sửa lý lịch cho cán bộ Trần Đình Thi - MS: 000');
INSERT INTO `user_log` (`Thoi_Gian`,`Ma_User_Thuc_Hien`,`Ma_CB_Thuc_Hien`,`Chuc_Nang`,`Noi_Dung`) VALUES ('2014-04-01 04:04:11','10','3','Sửa quá trình đi nước ngoài','Sửa quá trình đi nước ngoài cho cán bộ Trần Đình Thi - MS: 000');
INSERT INTO `user_log` (`Thoi_Gian`,`Ma_User_Thuc_Hien`,`Ma_CB_Thuc_Hien`,`Chuc_Nang`,`Noi_Dung`) VALUES ('2014-04-01 08:04:11','10','3','Sửa quá trình đi nước ngoài','Sửa lý lịch cho cán bộ Nguyễn Tuấn Anh - MS: 000');
/*!40000 ALTER TABLE `user_log` ENABLE KEYS */;


--
-- Create Table `yeu_cau_thay_đoi_tt_cb`
--

DROP TABLE IF EXISTS `yeu_cau_thay_đoi_tt_cb`;
CREATE TABLE `yeu_cau_thay_đoi_tt_cb` (
  `Ma_Yeu_Cau` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `Ma_CB_Anh_Huong` int(11) NOT NULL,
  `Ma_CB_Yeu_Cau` int(11) NOT NULL,
  `Ten_Yeu_Cau` varchar(254) DEFAULT NULL,
  `Loi_Noi` varchar(254) DEFAULT NULL,
  `Trang_Thai` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`Ma_Yeu_Cau`),
  KEY `FK_Anh_Huong_Can_bo` (`Ma_CB_Anh_Huong`),
  KEY `FK_đuoc_can_bo_yeu_cau` (`Ma_CB_Yeu_Cau`),
  CONSTRAINT `FK_Anh_Huong_Can_bo` FOREIGN KEY (`Ma_CB_Anh_Huong`) REFERENCES `can_bo` (`Ma_Can_Bo`),
  CONSTRAINT `FK_đuoc_can_bo_yeu_cau` FOREIGN KEY (`Ma_CB_Yeu_Cau`) REFERENCES `can_bo` (`Ma_Can_Bo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `yeu_cau_thay_đoi_tt_cb`
--

/*!40000 ALTER TABLE `yeu_cau_thay_đoi_tt_cb` DISABLE KEYS */;
/*!40000 ALTER TABLE `yeu_cau_thay_đoi_tt_cb` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

